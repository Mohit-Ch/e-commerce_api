(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["layouts-admin-layout-admin-layout-module"],{

/***/ "./node_modules/ngx-clipboard/__ivy_ngcc__/fesm5/ngx-clipboard.js":
/*!************************************************************************!*\
  !*** ./node_modules/ngx-clipboard/__ivy_ngcc__/fesm5/ngx-clipboard.js ***!
  \************************************************************************/
/*! exports provided: ClipboardDirective, ClipboardIfSupportedDirective, ClipboardModule, ClipboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClipboardDirective", function() { return ClipboardDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClipboardIfSupportedDirective", function() { return ClipboardIfSupportedDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClipboardModule", function() { return ClipboardModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClipboardService", function() { return ClipboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var ngx_window_token__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-window-token */ "./node_modules/ngx-window-token/__ivy_ngcc__/fesm5/ngx-window-token.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");






/**
 * The following code is heavily copied from https://github.com/zenorocha/clipboard.js
 */

var ClipboardService = /** @class */ (function () {
    function ClipboardService(document, window) {
        this.document = document;
        this.window = window;
        this.copySubject = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.copyResponse$ = this.copySubject.asObservable();
        this.config = {};
    }
    ClipboardService.prototype.configure = function (config) {
        this.config = config;
    };
    ClipboardService.prototype.copy = function (content) {
        if (!this.isSupported || !content) {
            return this.pushCopyResponse({ isSuccess: false, content: content });
        }
        var copyResult = this.copyFromContent(content);
        if (copyResult) {
            return this.pushCopyResponse({ content: content, isSuccess: copyResult });
        }
        return this.pushCopyResponse({ isSuccess: false, content: content });
    };
    Object.defineProperty(ClipboardService.prototype, "isSupported", {
        get: function () {
            return !!this.document.queryCommandSupported && !!this.document.queryCommandSupported('copy') && !!this.window;
        },
        enumerable: true,
        configurable: true
    });
    ClipboardService.prototype.isTargetValid = function (element) {
        if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
            if (element.hasAttribute('disabled')) {
                throw new Error('Invalid "target" attribute. Please use "readonly" instead of "disabled" attribute');
            }
            return true;
        }
        throw new Error('Target should be input or textarea');
    };
    /**
     * Attempts to copy from an input `targetElm`
     */
    ClipboardService.prototype.copyFromInputElement = function (targetElm, isFocus) {
        if (isFocus === void 0) { isFocus = true; }
        try {
            this.selectTarget(targetElm);
            var re = this.copyText();
            this.clearSelection(isFocus ? targetElm : undefined, this.window);
            return re && this.isCopySuccessInIE11();
        }
        catch (error) {
            return false;
        }
    };
    /**
     * This is a hack for IE11 to return `true` even if copy fails.
     */
    ClipboardService.prototype.isCopySuccessInIE11 = function () {
        var clipboardData = this.window['clipboardData'];
        if (clipboardData && clipboardData.getData) {
            if (!clipboardData.getData('Text')) {
                return false;
            }
        }
        return true;
    };
    /**
     * Creates a fake textarea element, sets its value from `text` property,
     * and makes a selection on it.
     */
    ClipboardService.prototype.copyFromContent = function (content, container) {
        if (container === void 0) { container = this.document.body; }
        // check if the temp textarea still belongs to the current container.
        // In case we have multiple places using ngx-clipboard, one is in a modal using container but the other one is not.
        if (this.tempTextArea && !container.contains(this.tempTextArea)) {
            this.destroy(this.tempTextArea.parentElement);
        }
        if (!this.tempTextArea) {
            this.tempTextArea = this.createTempTextArea(this.document, this.window);
            try {
                container.appendChild(this.tempTextArea);
            }
            catch (error) {
                throw new Error('Container should be a Dom element');
            }
        }
        this.tempTextArea.value = content;
        var toReturn = this.copyFromInputElement(this.tempTextArea, false);
        if (this.config.cleanUpAfterCopy) {
            this.destroy(this.tempTextArea.parentElement);
        }
        return toReturn;
    };
    /**
     * Remove temporary textarea if any exists.
     */
    ClipboardService.prototype.destroy = function (container) {
        if (container === void 0) { container = this.document.body; }
        if (this.tempTextArea) {
            container.removeChild(this.tempTextArea);
            // removeChild doesn't remove the reference from memory
            this.tempTextArea = undefined;
        }
    };
    /**
     * Select the target html input element.
     */
    ClipboardService.prototype.selectTarget = function (inputElement) {
        inputElement.select();
        inputElement.setSelectionRange(0, inputElement.value.length);
        return inputElement.value.length;
    };
    ClipboardService.prototype.copyText = function () {
        return this.document.execCommand('copy');
    };
    /**
     * Moves focus away from `target` and back to the trigger, removes current selection.
     */
    ClipboardService.prototype.clearSelection = function (inputElement, window) {
        inputElement && inputElement.focus();
        window.getSelection().removeAllRanges();
    };
    /**
     * Creates a fake textarea for copy command.
     */
    ClipboardService.prototype.createTempTextArea = function (doc, window) {
        var isRTL = doc.documentElement.getAttribute('dir') === 'rtl';
        var ta;
        ta = doc.createElement('textarea');
        // Prevent zooming on iOS
        ta.style.fontSize = '12pt';
        // Reset box model
        ta.style.border = '0';
        ta.style.padding = '0';
        ta.style.margin = '0';
        // Move element out of screen horizontally
        ta.style.position = 'absolute';
        ta.style[isRTL ? 'right' : 'left'] = '-9999px';
        // Move element to the same position vertically
        var yPosition = window.pageYOffset || doc.documentElement.scrollTop;
        ta.style.top = yPosition + 'px';
        ta.setAttribute('readonly', '');
        return ta;
    };
    /**
     * Pushes copy operation response to copySubject, to provide global access
     * to the response.
     */
    ClipboardService.prototype.pushCopyResponse = function (response) {
        this.copySubject.next(response);
    };
    /**
     * @deprecated use pushCopyResponse instead.
     */
    ClipboardService.prototype.pushCopyReponse = function (response) {
        this.pushCopyResponse(response);
    };
    ClipboardService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"],] }] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: [ngx_window_token__WEBPACK_IMPORTED_MODULE_3__["WINDOW"],] }] }
    ]; };
    ClipboardService.ɵprov = Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"])({ factory: function ClipboardService_Factory() { return new ClipboardService(Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"])(_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"])(ngx_window_token__WEBPACK_IMPORTED_MODULE_3__["WINDOW"], 8)); }, token: ClipboardService, providedIn: "root" });
    ClipboardService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([ Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"])), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"])()), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(ngx_window_token__WEBPACK_IMPORTED_MODULE_3__["WINDOW"]))
    ], ClipboardService);
ClipboardService.ɵfac = function ClipboardService_Factory(t) { return new (t || ClipboardService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](ngx_window_token__WEBPACK_IMPORTED_MODULE_3__["WINDOW"], 8)); };
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵsetClassMetadata"](ClipboardService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"],
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"],
                args: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]]
            }] }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"]
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"],
                args: [ngx_window_token__WEBPACK_IMPORTED_MODULE_3__["WINDOW"]]
            }] }]; }, null); })();
    return ClipboardService;
}());

var ClipboardDirective = /** @class */ (function () {
    function ClipboardDirective(clipboardSrv) {
        this.clipboardSrv = clipboardSrv;
        this.cbOnSuccess = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.cbOnError = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
    }
    // tslint:disable-next-line:no-empty
    ClipboardDirective.prototype.ngOnInit = function () { };
    ClipboardDirective.prototype.ngOnDestroy = function () {
        this.clipboardSrv.destroy(this.container);
    };
    ClipboardDirective.prototype.onClick = function (event) {
        if (!this.clipboardSrv.isSupported) {
            this.handleResult(false, undefined, event);
        }
        else if (this.targetElm && this.clipboardSrv.isTargetValid(this.targetElm)) {
            this.handleResult(this.clipboardSrv.copyFromInputElement(this.targetElm), this.targetElm.value, event);
        }
        else if (this.cbContent) {
            this.handleResult(this.clipboardSrv.copyFromContent(this.cbContent, this.container), this.cbContent, event);
        }
    };
    /**
     * Fires an event based on the copy operation result.
     * @param succeeded
     */
    ClipboardDirective.prototype.handleResult = function (succeeded, copiedContent, event) {
        var response = {
            isSuccess: succeeded,
            event: event
        };
        if (succeeded) {
            response = Object.assign(response, {
                content: copiedContent,
                successMessage: this.cbSuccessMsg
            });
            this.cbOnSuccess.emit(response);
        }
        else {
            this.cbOnError.emit(response);
        }
        this.clipboardSrv.pushCopyResponse(response);
    };
    ClipboardDirective.ctorParameters = function () { return [
        { type: ClipboardService }
    ]; };
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])('ngxClipboard')
    ], ClipboardDirective.prototype, "targetElm", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])()
    ], ClipboardDirective.prototype, "container", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])()
    ], ClipboardDirective.prototype, "cbContent", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])()
    ], ClipboardDirective.prototype, "cbSuccessMsg", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])()
    ], ClipboardDirective.prototype, "cbOnSuccess", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])()
    ], ClipboardDirective.prototype, "cbOnError", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"])('click', ['$event.target'])
    ], ClipboardDirective.prototype, "onClick", null);
ClipboardDirective.ɵfac = function ClipboardDirective_Factory(t) { return new (t || ClipboardDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](ClipboardService)); };
ClipboardDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineDirective"]({ type: ClipboardDirective, selectors: [["", "ngxClipboard", ""]], hostBindings: function ClipboardDirective_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ClipboardDirective_click_HostBindingHandler($event) { return ctx.onClick($event.target); });
    } }, inputs: { targetElm: ["ngxClipboard", "targetElm"], container: "container", cbContent: "cbContent", cbSuccessMsg: "cbSuccessMsg" }, outputs: { cbOnSuccess: "cbOnSuccess", cbOnError: "cbOnError" } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵsetClassMetadata"](ClipboardDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Directive"],
        args: [{
                selector: '[ngxClipboard]'
            }]
    }], function () { return [{ type: ClipboardService }]; }, { cbOnSuccess: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"]
        }], cbOnError: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"]
        }], onClick: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"],
            args: ['click', ['$event.target']]
        }], targetElm: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"],
            args: ['ngxClipboard']
        }], container: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"]
        }], cbContent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"]
        }], cbSuccessMsg: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"]
        }] }); })();
    return ClipboardDirective;
}());

var ClipboardIfSupportedDirective = /** @class */ (function () {
    function ClipboardIfSupportedDirective(_clipboardService, _viewContainerRef, _templateRef) {
        this._clipboardService = _clipboardService;
        this._viewContainerRef = _viewContainerRef;
        this._templateRef = _templateRef;
    }
    ClipboardIfSupportedDirective.prototype.ngOnInit = function () {
        if (this._clipboardService.isSupported) {
            this._viewContainerRef.createEmbeddedView(this._templateRef);
        }
    };
    ClipboardIfSupportedDirective.ctorParameters = function () { return [
        { type: ClipboardService },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewContainerRef"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["TemplateRef"] }
    ]; };
ClipboardIfSupportedDirective.ɵfac = function ClipboardIfSupportedDirective_Factory(t) { return new (t || ClipboardIfSupportedDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](ClipboardService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewContainerRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["TemplateRef"])); };
ClipboardIfSupportedDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineDirective"]({ type: ClipboardIfSupportedDirective, selectors: [["", "ngxClipboardIfSupported", ""]] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵsetClassMetadata"](ClipboardIfSupportedDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Directive"],
        args: [{
                selector: '[ngxClipboardIfSupported]'
            }]
    }], function () { return [{ type: ClipboardService }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewContainerRef"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["TemplateRef"] }]; }, null); })();
    return ClipboardIfSupportedDirective;
}());

var ClipboardModule = /** @class */ (function () {
    function ClipboardModule() {
    }
ClipboardModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ClipboardModule });
ClipboardModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ factory: function ClipboardModule_Factory(t) { return new (t || ClipboardModule)(); }, imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ClipboardModule, { declarations: function () { return [ClipboardDirective,
        ClipboardIfSupportedDirective]; }, imports: function () { return [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]; }, exports: function () { return [ClipboardDirective,
        ClipboardIfSupportedDirective]; } }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵsetClassMetadata"](ClipboardModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"],
        args: [{
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
                declarations: [ClipboardDirective, ClipboardIfSupportedDirective],
                exports: [ClipboardDirective, ClipboardIfSupportedDirective]
            }]
    }], function () { return []; }, null); })();
    return ClipboardModule;
}());

/*
 * Public API Surface of ngx-clipboard
 */

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=ngx-clipboard.js.map

/***/ }),

/***/ "./node_modules/ngx-window-token/__ivy_ngcc__/fesm5/ngx-window-token.js":
/*!******************************************************************************!*\
  !*** ./node_modules/ngx-window-token/__ivy_ngcc__/fesm5/ngx-window-token.js ***!
  \******************************************************************************/
/*! exports provided: WINDOW */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WINDOW", function() { return WINDOW; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var WINDOW = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('WindowToken', typeof window !== 'undefined' && window.document ? { providedIn: 'root', factory: function () { return window; } } : undefined);

/*
 * Public API Surface of ngx-window-token
 */

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=ngx-window-token.js.map

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/overview/overview.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/overview/overview.component.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header bg-gradient-danger pb-8 pt-5 pt-md-8\">\r\n    <div class=\"container-fluid\">\r\n        <div class=\"header-body\">\r\n            <!-- Card stats -->\r\n            <div class=\"row\">\r\n                <div class=\"col-xl-3 col-lg-6\" (click)=\"linkclick(1)\">\r\n                    <div class=\"card card-stats mb-4 mb-xl-0\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col\">\r\n                                    <h5 class=\"card-title text-uppercase text-muted mb-0\">Pending Orders</h5>\r\n                                    <span class=\"h2 font-weight-bold mb-0\">{{pendingOrder}}</span>\r\n                                </div>\r\n                                <div class=\"col-auto\">\r\n                                    <div class=\"icon icon-shape bg-yellow text-white rounded-circle shadow\">\r\n                                        <i class=\"fas fa-shopping-basket\"></i>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-xl-3 col-lg-6\" (click)=\"linkclick(2)\">\r\n                    <div class=\"card card-stats mb-4 mb-xl-0\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col\">\r\n                                    <h5 class=\"card-title text-uppercase text-muted mb-0\">New Users</h5>\r\n                                    <span class=\"h2 font-weight-bold mb-0\">{{newUserCount}}</span>\r\n                                </div>\r\n                                <div class=\"col-auto\">\r\n                                    <div class=\"icon icon-shape bg-yellow text-white rounded-circle shadow\">\r\n                                        <i class=\"fas fa-user-plus\"></i>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <!-- <div class=\"col-xl-3 col-lg-6\">\r\n                    <div class=\"card card-stats mb-4 mb-xl-0\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col\">\r\n                                    <h5 class=\"card-title text-uppercase text-muted mb-0\">Registred Users</h5>\r\n                                    <span class=\"h2 font-weight-bold mb-0\">{{RegisterUser}}</span>\r\n                                </div>\r\n                                <div class=\"col-auto\">\r\n                                    <div class=\"icon icon-shape bg-yellow text-white rounded-circle shadow\">\r\n                                        <i class=\"fas fa-user-check\"></i>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div> -->\r\n                <div class=\"col-xl-3 col-lg-6\" (click)=\"linkclick(3)\">\r\n                    <div class=\"card card-stats mb-4 mb-xl-0\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col\">\r\n                                    <h5 class=\"card-title text-uppercase text-muted mb-0\">Accepted Order</h5>\r\n                                    <span class=\"h2 font-weight-bold mb-0\">{{conformorder}}</span>\r\n                                </div>\r\n                                <div class=\"col-auto\">\r\n                                    <div class=\"icon icon-shape bg-yellow text-white rounded-circle shadow\">\r\n                                        <i class=\"fas fa-user-check\"></i>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-xl-3 col-lg-6\" (click)=\"linkclick(4)\">\r\n                    <div class=\"card card-stats mb-4 mb-xl-0\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col\">\r\n                                    <h5 class=\"card-title text-uppercase text-muted mb-0\">Running Offers</h5>\r\n                                    <span class=\"h2 font-weight-bold mb-0\" *ngIf=\"promotion!=null\">{{promotion}}</span>\r\n                                    <span class=\"h2 font-weight-bold mb-0\" *ngIf=\"promotion==null\">0</span>\r\n                                </div>\r\n                                <div class=\"col-auto\">\r\n                                    <!-- <div class=\"icon icon-shape bg-info text-white rounded-circle shadow\">\r\n                                        <i class=\"fas fa-percent\"></i>\r\n                                    </div> -->\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/accepted-orders/accepted-orders.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/accepted-orders/accepted-orders.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<app-loading-spinner *ngIf=\"loading\"></app-loading-spinner>\r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">Orders Need to be delivered</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\"  >\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\">User Name</th>\r\n                                <th scope=\"col\">User Type</th>\r\n                                <th scope=\"col\">Delivery Address</th>\r\n                                <th scope=\"col\">Contact number</th>\r\n                                <th scope=\"col\">Order Amount</th>\r\n                                <th scope=\"col\">Order detail</th>\r\n                                <th scope=\"col\">Action</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"OrderList!=null && OrderList.length>0\">\r\n                            <tr *ngFor=\"let item of OrderList\">\r\n                                <th scope=\"row\">\r\n                                    {{item.s_no}}.\r\n                                </th>\r\n                                <td>\r\n                                    {{item.userName}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.usertype}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.address}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.phone_no}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.amount}} KWD\r\n                                </td>\r\n                                <td>\r\n                                    <a (click)=\"detailClick(item.order_Id)\">Detail</a>\r\n                                </td>\r\n                                <td>\r\n                                    <button (click)=\"onDeliveredClick(item.order_Id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-shipping-fast\"></i></button>\r\n                                    <button (click)=\"onCancelClick(item.order_Id)\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-times\"></i></button>\r\n                                </td>\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"OrderList==undefined ||  OrderList.length==0\" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-category/add-category.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-category/add-category.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row\">\r\n        <div class=\"col-xl-12\">\r\n            <div class=\"card bg-secondary shadow\">\r\n                <div class=\"card-header bg-white border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col-8\">\r\n                            <h3 class=\"mb-0\">Add a new Category</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"card-body\">\r\n                   \r\n                        <div class=\"pl-lg-4\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-lg-6 order-xl-3\">\r\n                                    <div class=\"form-group\">\r\n                                        <label class=\"form-control-label\" for=\"input-category\">Category</label>\r\n                                        <input type=\"text\" id=\"input-category\"\r\n                                            class=\"form-control form-control-alternative\" placeholder=\"Ex. Power tools\"\r\n                                            value=\"\" [(ngModel)]=\"category\">\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"col-lg-6 order-xl-3\">\r\n                                    <div class=\"form-group\" *ngIf=\"imageShow==false\">\r\n                                        <label class=\"form-control-label\" for=\"input-category\">Upload Category Image</label>\r\n                                        <input type=\"file\"  accept=\"image/*\" class=\"form-control form-control-alternative\"  (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload Category Image\" id=\"upload-image\">\r\n                                    </div>\r\n                                    <div class=\"form-group\" *ngIf=\"imageShow==true\">\r\n                                        <div class=\"row\"> \r\n                                            <div class=\"col-lg-5\"><img [src]=\"imagePath\" width=\"150px\" ></div>\r\n                                            <div class=\"col-lg-7\">\r\n                                                <label class=\"form-control-label\" for=\"input-category\">Upload Category Image</label>\r\n                                                <input type=\"file\"  accept=\"image/*\"  style=\"width: 300px;\" class=\"form-control form-control-alternative\"  (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload Category Image\" id=\"upload-image\">\r\n\r\n                                            </div>\r\n                                        \r\n                                      </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <!-- <hr class=\"my-4\" /> -->\r\n                        <div class=\"pl-lg-4\">\r\n                            <button (click)=\"saveCategory()\" class=\"btn btn-md btn-primary\">Save</button>\r\n                        </div>\r\n                   \r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-offers/add-offers.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-offers/add-offers.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \n    <p style=\"color: white\">Please Wait. </p>  \n    </ngx-spinner> \n<div *ngIf=\"dataArray!=undefined\">\n    <app-overview [data]=\"dataArray\"></app-overview>\n  </div>\n<div class=\"container-fluid mt--7\">\n    <div class=\"row\">\n        <div class=\"col-xl-12\">\n            <div class=\"card bg-secondary shadow\">\n                <div class=\"card-header bg-white border-0\">\n                    <div class=\"row align-items-center\">\n                        <div class=\"col-8\">\n                            <h3 class=\"mb-0\">Add a new Offer</h3>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"card-body\">\n                   \n                        <div class=\"pl-lg-4\">\n                            <div class=\"row\">\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Amount *</label>\n                                        <div class=\"input-group input-group-alternative\">\n                                            <div class=\"input-group-prepend\">\n                                                <span class=\"input-group-text\" *ngIf=\"type=='percentage'\">%</span>\n                                                <span class=\"input-group-text\" *ngIf=\"type=='fixed'\">KWD</span>\n                                            </div>\n                                            <input class=\"form-control datepicker\"[(ngModel)]=\"amount\" placeholder=\"Ex.100\" type=\"text\">\n                                        </div>\n                                    </div>\n                                </div>\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Offer Type</label>\n                                        <select class=\"form-control form-control-alternative\" [(ngModel)]=\"type\"  placeholder=\"Select \n                                        Type\">\n                                            <option value=\"fixed\">Fixed</option>\n                                            <option selected value=\"percentage\">Percentage</option>\n                                        </select>\n                                           \n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"row\">\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Minimum Amount to be applied *</label>\n                                        <input type=\"text\"\n                                            class=\"form-control form-control-alternative\" [(ngModel)]=\"minamount\" placeholder=\"Ex.100\"\n                                            value=\"\">\n                                    </div>\n                                </div>\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Max Amount to be deduct *</label>\n                                        <input type=\"text\"\n                                            class=\"form-control form-control-alternative\" [(ngModel)]=\"maxamount\" placeholder=\"Ex.100\"\n                                            value=\"\">\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"row\">\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Start Date *</label>\n                                        <div class=\"input-group input-group-alternative\">\n                                            <div class=\"input-group-prepend\">\n                                                <span class=\"input-group-text\"><i class=\"ni ni-calendar-grid-58\"></i></span>\n                                            </div>\n                                            <input class=\"form-control\" placeholder=\"Select date\" type=\"text\"  name=\"dp\"  [(ngModel)]=\"startdate\" ngbDatepicker #c=\"ngbDatepicker\" (click)=\"c.toggle()\" required >\n                                        </div>\n                                        <p style=\"color: red;\" *ngIf=\"errormessagestart\"> please select the start date</p>\n                                    </div>\n                                </div>\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">End Date *</label>\n                                        <div class=\"input-group input-group-alternative\">\n                                            <div class=\"input-group-prepend\">\n                                                <span class=\"input-group-text\"><i class=\"ni ni-calendar-grid-58\"></i></span>\n                                            </div>\n                                            <input class=\"form-control\" placeholder=\"Select date\" type=\"text\" name=\"enddate\" [(ngModel)]=\"enddate\" ngbDatepicker #d=\"ngbDatepicker\" (click)=\"d.toggle()\"\n                                            (dateSelect)=\"datechange($event)\"   required >\n                                        </div>\n                                        <p style=\"color: red;\" *ngIf=\"errormessageEnd\"> please select the another end date</p>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"row\">\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Code</label>\n                                        <input class=\"form-control datepicker\" placeholder=\"Code\" type=\"text\" [(ngModel)]=\"code\"  readonly>\n                                    </div>\n                                </div>\n                                <div class=\"col-lg-6 order-xl-3\">\n                                    <div class=\"form-group\">\n                                        <label class=\"form-control-label\" for=\"input-category\">Description *</label>\n                                        <input class=\"form-control datepicker\" placeholder=\"Description\" type=\"text\"  [(ngModel)]=\"description\">\n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                        <p style=\"color: red;\" *mgIf=\"error\">please enter all the required field</p>\n                        <!-- <hr class=\"my-4\" /> -->\n                        <div class=\"pl-lg-4\">\n                            <button (click)=\"savechange()\" class=\"btn btn-md btn-primary\">Save</button>\n                        </div>\n                   \n                </div>\n            </div>\n        </div>\n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-product/add-product.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-product/add-product.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n</div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row\">\r\n        <div class=\"col-xl-12\">\r\n            <div class=\"card bg-secondary shadow\">\r\n                <div class=\"card-header bg-white border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col-8\">\r\n                            <h3 class=\"mb-0\">Add a new Product</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"card-body\">\r\n                    <div class=\"pl-lg-4\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Select\r\n                    Category</label>\r\n                                    <select class=\"form-control form-control-alternative\" [(ngModel)]=\"categoryId\" *ngIf=\"categoryList != undefined\" placeholder=\"Select Category\" (change)=\"categorychange()\">\r\n                    <option selected value=\"0\">Select</option>\r\n                    <option *ngFor=\"let item of categoryList\" [ngValue]=\"item.id\">{{item.category_name}}</option>\r\n                  </select>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Select Sub Category</label>\r\n                                    <select class=\"form-control form-control-alternative\" [(ngModel)]=\"SubcategoryId\" *ngIf=\"subCategoryList != undefined\" placeholder=\"Select Sub Category\">\r\n                                    <option selected value=\"0\">Select</option>\r\n                                    <option *ngFor=\"let item of subCategoryList\" [ngValue]=\"item.id\">{{item.category_name}}</option>\r\n                                </select>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <hr class=\"my-4\" />\r\n                    <div class=\"pl-lg-4\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Name</label>\r\n                                    <input type=\"text\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" placeholder=\"Ex. Brand Name\" value=\"\" [(ngModel)]=\"productName\" (input)=\"AddName()\">\r\n                                </div>\r\n                            </div>\r\n                            \r\n                        </div>\r\n                    </div>\r\n                    <hr class=\"my-4\" />\r\n                    <div class=\"pl-lg-4\">\r\n                        <div class=\"row align-items-center\">\r\n                            <div class=\"col-8\">\r\n                                <h3 class=\"mb-0\">Upload Product Image</h3>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">product Image Type</label>\r\n                                    <select class=\"form-control form-control-alternative\" [(ngModel)]=\"ImageType\" placeholder=\"Select Category\">\r\n                                          <option selected value=\"Select\">Select</option>\r\n                                          <option value=\"Main\" *ngIf=\"showMainImage\">Main</option>\r\n                                          <option value=\"Other\">Other</option>\r\n                                        </select>\r\n                                </div>\r\n                                <p *ngIf=\"showImageError\" style=\"color: red;\"> Please Select the Image Type </p>\r\n                            </div>\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Select product Image</label>\r\n                                    <input type=\"file\" accept=\"image/*\" style=\"width: 300px;\" class=\"form-control form-control-alternative\" (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload Category Image\" id=\"upload-image\">\r\n                                </div>\r\n\r\n                            </div>\r\n                        </div>\r\n                        <hr class=\"my-4\" *ngIf=\"showImageGrid\" />\r\n                        <div class=\"row align-items-center\" *ngIf=\"showImageGrid\">\r\n                            <div class=\"col-8\">\r\n                                <h3 class=\"mb-0\">Product Image List</h3>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\" *ngIf=\"showImageGrid\">\r\n                            <div class=\"table-responsive\">\r\n                                <!-- Projects table -->\r\n                                <table class=\"table align-items-center table-flush\">\r\n                                    <thead class=\"thead-light\">\r\n                                        <tr>\r\n                                            <th scope=\"col\">S.No</th>\r\n                                            <th scope=\"col\">Image Type</th>\r\n                                            <th scope=\"col\">image</th>\r\n                                            <th scope=\"col\">Action</th>\r\n                                        </tr>\r\n                                    </thead>\r\n                                    <tbody *ngIf=\"imageGrid!=undefined\">\r\n                                        <tr *ngFor=\"let item of imageGrid; let i=index\">\r\n                                            <th scope=\"row\">\r\n                                                {{i+1}}\r\n                                            </th>\r\n                                            <td>\r\n                                                {{item.image_type}}\r\n                                            </td>\r\n                                            <td>\r\n                                                <img [src]=\"item.imageUrl || 'http://placehold.it/180'\" width=\"150px\">\r\n                                            </td>\r\n                                            <td>\r\n\r\n                                                <button (click)=\"DeleteImage(item,i)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button>\r\n                                            </td>\r\n                                        </tr>\r\n                                    </tbody>\r\n                                </table>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <hr class=\"my-4\" />\r\n                    <div class=\"pl-lg-4 \">\r\n                        <div class=\"row align-items-center\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <h2 class=\"mb-0\">Add Product Editioin</h2>\r\n                            </div>\r\n                            <div class=\"col-lg-6 order-xl-3 \">\r\n                                <div class=\"form-group mb-0\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\" style=\"padding-right: 20px;\">Multiple Edition</label>\r\n                                    <input type=\"checkbox\" id=\"vehicle1\" lass=\"form-control form-control-alternative\" name=\"vehicle1\" [(ngModel)]=\"multipleSub\" (ngModelChange)=\"SelectMultie()\">\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Edition Name</label>\r\n                                    <input type=\"text\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" placeholder=\"Ex. Edition Name\" (input)=\"CheckName()\" [(ngModel)]=\"EditionName\">\r\n                                </div>\r\n                                <p *ngIf=\"showEdError\"> Edition name is not same as product name </p>\r\n                            </div>\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">price</label>\r\n                                    <div class=\"input-group input-group-alternative\">\r\n                                        <div class=\"input-group-prepend\">\r\n                                            <span class=\"input-group-text\" >Dinar</span>\r\n                                        </div>\r\n                                        <input type=\"number\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" placeholder=\"Ex. Price\" value=\"\" [(ngModel)]=\"price\">\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Quantity</label>\r\n                                    <input type=\"number\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" placeholder=\"Ex. Quantity\" value=\"\" [(ngModel)]=\"quantity\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Remark</label>\r\n                                    <input type=\"text\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" placeholder=\"Ex. Remark\" value=\"\" [(ngModel)]=\"remark\">\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\" *ngIf=\"showErrorEdition\" style=\"color: red;\">\r\n                            <p> Plese enter Menditory Field Edition Name, Price and Quantity </p>\r\n                        </div>\r\n                        <div class=\"row\" *ngIf=\"showEditopnAddmore\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <button (click)=\"AddMoreEdition()\" class=\"btn btn-md btn-primary\">Add More</button>\r\n                            </div>\r\n                        </div>\r\n                        <hr class=\"my-4\" *ngIf=\"ShowEditiontable\" />\r\n                        <div class=\"row align-items-center\" *ngIf=\"ShowEditiontable\">\r\n                            <div class=\"col-8\">\r\n                                <h3 class=\"mb-0\">Editioin List</h3>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\" *ngIf=\"ShowEditiontable\">\r\n                            <div class=\"table-responsive\">\r\n                                <!-- Projects table -->\r\n                                <table class=\"table align-items-center table-flush\">\r\n                                    <thead class=\"thead-light\">\r\n                                        <tr>\r\n                                            <th scope=\"col\">S.No</th>\r\n                                            <th scope=\"col\">Product Edition Name</th>\r\n                                            <th scope=\"col\">Quantity</th>\r\n                                            <th scope=\"col\">Price</th>\r\n                                            <th scope=\"col\">Remark</th>\r\n                                            <th scope=\"col\">Action</th>\r\n                                        </tr>\r\n                                    </thead>\r\n                                    <tbody *ngIf=\"EditionList!=undefined\">\r\n                                        <tr *ngFor=\"let item of EditionList; let i = index  \">\r\n                                            <th scope=\"row\">\r\n                                                {{i+1}}\r\n                                            </th>\r\n                                            <td>\r\n                                                {{item.EditionName}}\r\n                                            </td>\r\n                                            <td>\r\n                                                {{item.quantity}}\r\n                                            </td>\r\n                                            <td>\r\n                                                KWD {{item.price}}\r\n                                            </td>\r\n                                            <td>\r\n                                                {{item.Remark}}\r\n                                            </td>\r\n                                            <td>\r\n                                                <button (click)=\"editEdition(item)\" class=\"btn btn-sm btn-primary\" *ngIf=\"item.id!=0\"><i class=\"fas fa-pencil-alt\"></i></button>\r\n                                                <button (click)=\"DeleteEdition(item)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button>\r\n                                            </td>\r\n                                        </tr>\r\n                                    </tbody>\r\n                                </table>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <hr class=\"my-4\" />\r\n                    <div class=\"pl-lg-4\">\r\n                        <div class=\"row align-items-center\">\r\n                            <div class=\"col-8\">\r\n                                <h3 class=\"mb-0\">product Description</h3>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-8 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Description</label>\r\n                                    <textarea ng-model=\"myTextarea\" [(ngModel)]=\"descritption\" class=\"form-control form-control-alternative\" placeholder=\"Ex. Describe your product...\"></textarea>\r\n\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <hr class=\"my-4\" />\r\n                    <div class=\"pl-lg-4\">\r\n                        <div class=\"row align-items-center\">\r\n                            <div class=\"col-8\">\r\n                                <h3 class=\"mb-0\">Additional Informaation</h3>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Additional Key</label>\r\n                                    <input type=\"text\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" [(ngModel)]=\"AddKey\" placeholder=\"Ex. Brand Name\" value=\"\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <div class=\"form-group\">\r\n                                    <label class=\"form-control-label\" for=\"input-sub-category\">Additional Value</label>\r\n                                    <input type=\"text\" id=\"input-sub-category\" class=\"form-control form-control-alternative\" [(ngModel)]=\"AddValue\" placeholder=\"Ex. Brand Name\" value=\"\">\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-6 order-xl-3\">\r\n                                <button (click)=\"AddAditioninfo()\" class=\"btn btn-md btn-primary\">{{addtionbutton}}</button>\r\n                            </div>\r\n                        </div>\r\n                        <hr class=\"my-4\" *ngIf=\"ShowEditionGrid\" />\r\n                        <div class=\"row align-items-center\" *ngIf=\"ShowEditionGrid\">\r\n                            <div class=\"col-8\">\r\n                                <h3 class=\"mb-0\">Additional Informaation List</h3>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\" *ngIf=\"ShowEditionGrid\">\r\n                            <div class=\"table-responsive\">\r\n                                <!-- Projects table -->\r\n                                <table class=\"table align-items-center table-flush\">\r\n                                    <thead class=\"thead-light\">\r\n                                        <tr>\r\n                                            <th scope=\"col\">S.No</th>\r\n                                            <th scope=\"col\">Key </th>\r\n                                            <th scope=\"col\">Value</th>\r\n                                            <th scope=\"col\">Action</th>\r\n                                        </tr>\r\n                                    </thead>\r\n                                    <tbody *ngIf=\"additionList!=undefined\">\r\n                                        <tr *ngFor=\"let item of additionList; let i=index\">\r\n                                            <th scope=\"row\">\r\n                                                {{i+1}}\r\n                                            </th>\r\n                                            <td>\r\n                                                {{item.key}}\r\n                                            </td>\r\n                                            <td>\r\n                                                {{item.value}}\r\n                                            </td>\r\n                                            <td>\r\n                                                <button (click)=\"editinfo(item)\" class=\"btn btn-sm btn-primary\" *ngIf=\"item.id!=0\"><i class=\"fas fa-pencil-alt\"></i></button>\r\n                                                <button (click)=\"Deleteinfo(item, index)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button>\r\n                                            </td>\r\n                                        </tr>\r\n                                    </tbody>\r\n                                </table>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"row\" style=\"float: right;\">\r\n                        <div class=\"pl-lg-4 \">\r\n                            <button (click)=\"saveproduct()\" class=\"btn btn-md btn-primary\">Save Product </button>\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-sub-category/add-sub-category.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-sub-category/add-sub-category.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row\">\r\n        <div class=\"col-xl-12\">\r\n            <div class=\"card bg-secondary shadow\">\r\n                <div class=\"card-header bg-white border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col-8\">\r\n                            <h3 class=\"mb-0\">Add a new Sub-Category</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"card-body\">\r\n                  \r\n                        <div class=\"pl-lg-4\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-lg-6 order-xl-3\">\r\n                                    <div class=\"form-group\">\r\n                                        <label class=\"form-control-label\" for=\"input-sub-category\">Select\r\n                                            Category</label>\r\n                                        <!-- <input type=\"text\" id=\"input-sub-category\"\r\n                                            class=\"form-control form-control-alternative\" placeholder=\"Ex. Brand Name\"\r\n                                            value=\"\"> -->\r\n                                        <select class=\"form-control form-control-alternative\" [(ngModel)]=\"categoryId\" *ngIf=\"categoryList != undefined\" placeholder=\"Select\r\n                                        Category\">\r\n                                            <option selected value=\"0\">Select</option>\r\n                                            <option *ngFor=\"let item of categoryList\" [ngValue]=\"item.id\">{{item.category_name}}</option>\r\n                                           \r\n                                        </select>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <hr class=\"my-4\" />\r\n                        <div class=\"pl-lg-4\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-lg-6 order-xl-3\">\r\n                                    <div class=\"form-group\">\r\n                                        <label class=\"form-control-label\" for=\"input-sub-category\">Sub-Category</label>\r\n                                        <input type=\"text\" id=\"input-sub-category\"\r\n                                            class=\"form-control form-control-alternative\" placeholder=\"Ex. Brand Name\" [(ngModel)]=\"SubcategoryName\"\r\n                                            value=\"\">\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"col-lg-6 order-xl-3\">\r\n                                    <div class=\"form-group\" *ngIf=\"imageShow==false\">\r\n                                        <label class=\"form-control-label\" for=\"input-category\">Upload sub Category Image</label>\r\n                                        <input type=\"file\"  accept=\"image/*\" class=\"form-control form-control-alternative\"  (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload Category Image\" id=\"upload-image\">\r\n                                    </div>\r\n                                    <div class=\"form-group\" *ngIf=\"imageShow==true\">\r\n                                        <div class=\"row\"> \r\n                                            <div class=\"col-lg-5\"><img [src]=\"imagePath\" width=\"150px\" ></div>\r\n                                            <div class=\"col-lg-7\">\r\n                                                <label class=\"form-control-label\" for=\"input-category\">Upload Category Image</label>\r\n                                                <input type=\"file\"  accept=\"image/*\"  style=\"width: 300px;\" class=\"form-control form-control-alternative\"  (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload Category Image\" id=\"upload-image\">\r\n\r\n                                            </div>\r\n                                        \r\n                                      </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"pl-lg-4\">\r\n                            <button (click)=\"saveSubCategory()\" class=\"btn btn-md btn-primary\">Save</button>\r\n                        </div>\r\n                  \r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/all-orders/all-orders.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/all-orders/all-orders.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">Completed Orders</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\" >\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\">User Name</th>\r\n                                <th scope=\"col\">User Type</th>\r\n                                <th scope=\"col\">Delivery Address</th>\r\n                                <th scope=\"col\">Contact number</th>\r\n                                <th scope=\"col\">Order Amount</th>\r\n                                <th scope=\"col\">Order detail</th>\r\n                                <!-- <th scope=\"col\">Action</th> -->\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"OrderList!=null && OrderList.length>0\">\r\n                            <tr *ngFor=\"let item of OrderList\">\r\n                                <th scope=\"row\">\r\n                                    {{item.s_no}}.\r\n                                </th>\r\n                                <td>\r\n                                    {{item.userName}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.usertype}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.address}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.phone_no}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.amount}} KWD\r\n                                </td>\r\n                                <td>\r\n                                    <a (click)=\"detailClick(item.order_Id)\">Detail</a>\r\n                                </td>\r\n                                <!-- <td>\r\n                                    <a href=\"\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-times\"></i></a>\r\n                                </td> -->\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"OrderList==undefined || OrderList.length==0 \" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/categories/categories.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/categories/categories.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">Categories</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\">\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\">Category</th>\r\n                                <th scope=\"col\">Photo</th>\r\n                                <th scope=\"col\">Action</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"categoryList!=undefined && categoryList!=''\">\r\n                            <tr *ngFor=\"let item of categoryList\">\r\n                                <th scope=\"row\" >\r\n                                    {{item.s_no}}\r\n                                </th>\r\n                                <td>\r\n                                    {{item.category_name}}\r\n                                </td>\r\n                                <td>\r\n                                    <img [src]=\"item.photo\" width=\"150px\" >\r\n                                   \r\n                                </td>\r\n                                <td>\r\n                                    <button (click)=\"Editcategory(item.id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-pencil-alt\"></i></button>\r\n                                    <button (click)=\"Deletecategory(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button>\r\n                                </td>\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"categoryList==undefined || categoryList.length==0\" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/dashboard.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/dashboard.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n  <p style=\"color: white\">Please Wait. </p>  \r\n  </ngx-spinner> \r\n\r\n<div *ngIf=\"dataArray!=undefined\">\r\n  <app-overview [data]=\"dataArray\"></app-overview>\r\n</div>\r\n\r\n<div class=\"container-fluid mt--7\">\r\n  <div class=\"row mt-5\">\r\n    <div class=\"col-xl-12 \">\r\n      <div class=\"card shadow\">\r\n        <div class=\"card-header border-0\">\r\n          <div class=\"row align-items-center\">\r\n            <div class=\"col\">\r\n              <h3 class=\"mb-0\">Recent Orders</h3>\r\n            </div>\r\n\r\n            <div class=\"col text-right\">\r\n              <button class=\"btn btn-sm btn-primary\" (click)=\"SeeAllOrdes()\">See all</button>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-responsive\" >\r\n          <!-- Projects table -->\r\n          <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n            <thead class=\"thead-light\">\r\n              <tr>\r\n                <th scope=\"col\">S.No</th>\r\n                <th scope=\"col\">User Name</th>\r\n                <th scope=\"col\">User Type</th>\r\n                <th scope=\"col\">Delivery Address</th>\r\n                <th scope=\"col\">Contact number</th>\r\n                <th scope=\"col\">Order Amount</th>\r\n                <th scope=\"col\">Order detail</th>\r\n                <th scope=\"col\">Action</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody *ngIf=\"newOrderList!=null && newOrderList.length>0\">\r\n              <tr *ngFor=\"let item of newOrderList\">\r\n                <th scope=\"row\">\r\n                  {{item.s_no}}.\r\n                </th>\r\n                <td>\r\n                  {{item.userName}}\r\n                </td>\r\n                <td>\r\n                  {{item.usertype}}\r\n                </td>\r\n                <td>\r\n                  {{item.address}}\r\n                </td>\r\n                <td>\r\n                  {{item.phone_no}}\r\n                </td>\r\n                <td>\r\n                  {{item.amount}} KWD\r\n                </td>\r\n                <td>\r\n                  <a (click)=\"detailClick(item.order_Id)\">Detail</a>\r\n                </td>\r\n                <td>\r\n                  <button (click)=\"onConformClick(item.order_Id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-check\"></i></button>\r\n                  <button (click)=\"onCancelClick(item.order_Id)\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-times\"></i></button>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"newOrderList==undefined|| newOrderList.length==0\" style=\"text-align: center;\">\r\n          <div class=\"col-xl-12\">\r\n            <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row mt-5\">\r\n    <div class=\"col-xl-12 \">\r\n      <div class=\"card shadow\">\r\n        <div class=\"card-header border-0\">\r\n          <div class=\"row align-items-center\">\r\n            <div class=\"col\">\r\n              <h3 class=\"mb-0\">Recent Users</h3>\r\n            </div>\r\n\r\n            <div class=\"col text-right\">\r\n              <button  class=\"btn btn-sm btn-primary\" (click)=\"seeallUsers()\">See all</button>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-responsive\" >\r\n          <!-- Projects table -->\r\n          <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptionsU\" [dtTrigger]=\"dtTriggerU\">\r\n            <thead class=\"thead-light\">\r\n              <tr>\r\n                <th scope=\"col\">S.No</th>\r\n                <th scope=\"col\">User Name</th>\r\n                <th scope=\"col\">Contact number</th>\r\n                <th scope=\"col\">Company name</th>\r\n                <th scope=\"col\">Action</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody *ngIf=\"newUserList!=null && newUserList.length>0\">\r\n              <tr *ngFor=\"let item of newUserList \">\r\n                <th scope=\"row\">\r\n                  {{item.s_no}}.\r\n                </th>\r\n                <td>\r\n                  {{item.name}} \r\n                </td>\r\n                <td>\r\n                  {{item.phone_no}}\r\n                </td>\r\n                <td>\r\n                  {{item.company_name}}\r\n                </td>\r\n                <td> \r\n                  <button (click)=\"onActiveClick(item.id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-check\"></i></button>\r\n                  <button (click)=\"onRejectClick(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-times\"></i></button>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"newUserList==undefined || newUserList.length==0\" style=\"text-align: center;\">\r\n          <div class=\"col-xl-12\">\r\n            <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/detail.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/detail.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<h1 mat-dialog-title>{{data.order_no}}</h1>\n<div mat-dialog-content> \n  <div class=\"table-responsive\" *ngIf=\"data.itemList!=null && data.itemList!=undefined\">\n    <table class=\"table align-items-center table-flush\">\n      <thead class=\"thead-light\">\n        <tr>\n          <th scope=\"col\">Image</th>\n          <th scope=\"col\">Item Detail</th>\n          <th scope=\"col\">Quantity</th>\n          <th scope=\"col\">price</th>\n        </tr>\n      </thead>\n      <tbody >\n        <tr *ngFor=\"let item of data.itemList\">\n          <th scope=\"row\">\n            <img [src]=\"item.imageURL\" width=\"40px\">\n          </th>\n          <td>\n            {{item.itemName}},<br/> {{item.itemEditionName}}\n          </td>\n          <td>\n            {{item.quantity}}\n          </td>\n          <td>\n            {{item.price}}\n          </td>         \n        </tr>\n      </tbody>\n    </table>\n  </div>\n  <div class=\"row mt-5\">\n    <div class=\"col-xl-12\">\n      <div class=\"col-xl-8\">\n        SubTotal -\n      </div>\n      <div class=\"col-xl-4\" style=\"float: right;\">\n        {{data.product_amount}}\n      </div>\n    </div>\n    <div class=\"col-xl-12\">\n      <div class=\"col-xl-8\">\n        Discount -\n      </div>\n      <div class=\"col-xl-4\" style=\"float: right;\">\n        {{data.Discount}}\n      </div>\n    </div>\n    <div class=\"col-xl-12\">\n      <div class=\"col-xl-8\">\n        Total -\n      </div>\n      <div class=\"col-xl-4\" style=\"float: right;\">\n        {{data.actual_amount}}\n      </div>\n    </div>\n  </div>\n  \n</div>\n<div mat-dialog-actions style=\"float: right;\">\n    <div class=\"row\" >\n        <button mat-button (click)=\"onNoClick()\"  class=\"btn btn-md btn-danger\" style=\"margin: 5px;\" >Cancel</button>\n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/dialogbox.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/dialogbox.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<h1 mat-dialog-title>{{data.type}}</h1>\n<div mat-dialog-content>\n  <p>{{data.Message}}</p>\n</div>\n<div mat-dialog-actions style=\"float: right;\">\n    <div class=\"row\" >\n        <button mat-button (click)=\"onNoClick()\" class=\"btn btn-md btn-danger\"  style=\"margin: 5px;\" >Cancel</button>\n        <button mat-button (click)=\"onConformClick()\" class=\"btn btn-md btn-primary\"  style=\"margin: 5px;\">Conform</button>\n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/offers-list/offers-list.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/offers-list/offers-list.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \n    <p style=\"color: white\">Please Wait. </p>  \n    </ngx-spinner> \n<div *ngIf=\"dataArray!=undefined\">\n    <app-overview [data]=\"dataArray\"></app-overview>\n</div>\n<div class=\"container-fluid mt--7\">\n    <div class=\"row mt-5\">\n        <div class=\"col-xl-12 \">\n            <div class=\"card shadow\">\n                <div class=\"card-header border-0\">\n                    <div class=\"row align-items-center\">\n                        <div class=\"col\">\n                            <h3 class=\"mb-0\">All Offers</h3>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"table-responsive\">\n                    <!-- Projects table -->\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\n                        <thead class=\"thead-light\">\n                            <tr>\n                                <th scope=\"col\">S.No</th>\n                                <th scope=\"col\">Offer Type</th>\n                                <th scope=\"col\">Amount</th>\n                                <th scope=\"col\">Code</th>\n                                <th scope=\"col\">Start date</th>\n                                <th scope=\"col\">End Date</th>\n                                <th scope=\"col\">Action</th>\n                            </tr>\n                        </thead>\n                        <tbody *ngIf=\"OfferList!=undefined\">\n                            <tr *ngFor=\"let item of OfferList; let i=index\">\n                                <th scope=\"row\">\n                                    {{i+1}}\n                                </th>\n                                <td class=\"text-uppercase\">\n                                    {{item.type}}\n                                </td>\n                                <td>\n                                    {{item.amount}}\n                                </td>\n                                <td>\n                                    {{item.code}}\n                                </td>\n                                <td>\n                                    {{item.start_date}}\n                                </td>\n                                <td>\n                                    {{item.end_date}}\n\n                                </td>\n                                <td>\n                                    <button (click)=\"Edit(item.id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-pencil-alt\"></i></button>\n                                    <!-- <button (click)=\"Delete(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button> -->\n                                </td>\n                            </tr>\n                        </tbody>\n                    </table>\n                </div>\n                <div class=\"row\" *ngIf=\"OfferList==undefined || OfferList.length==0\" style=\"text-align: center;\">\n                    <div class=\"col-xl-12\">\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\n                    </div>\n                  </div>\n            </div>\n        </div>\n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pending-orders/pending-orders.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pending-orders/pending-orders.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n<app-overview [data]=\"dataArray\"></app-overview>\r\n</div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">Confirm/Reject Orders</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\" *ngIf=\"newOrderList!=null && newOrderList.length>0\">\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\">User Name</th>\r\n                                <th scope=\"col\">User Type</th>\r\n                                <th scope=\"col\">Delivery Address</th>\r\n                                <th scope=\"col\">Contact number</th>\r\n                                <th scope=\"col\">Order Amount</th>\r\n                                <th scope=\"col\">Order detail</th>\r\n                                <th scope=\"col\">Action</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"newOrderList!=null && newOrderList.length>0\">\r\n                            <tr *ngFor=\"let item of newOrderList\">\r\n                                <th scope=\"row\">\r\n                                    {{item.s_no}}.\r\n                                </th>\r\n                                <td>\r\n                                    {{item.userName}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.usertype}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.address}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.phone_no}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.amount}} KWD\r\n                                </td>\r\n                                <td>\r\n                                    <a (click)=\"detailClick(item.order_Id)\">Detail</a>\r\n                                </td>\r\n                                <td>\r\n                                    <button (click)=\"onConformClick(item.order_Id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-check\"></i></button>\r\n                                    <button (click)=\"onCancelClick(item.order_Id)\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-times\"></i></button>\r\n                                </td>\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"newOrderList==undefined ||newOrderList.length==0\" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pending-users/pending-users.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pending-users/pending-users.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">Confirm/Reject Users</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\" >\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\">User Name</th>\r\n                                <th scope=\"col\">Contact number</th>\r\n                                <th scope=\"col\">Company name</th>\r\n                                <th scope=\"col\">Action</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"newUserList!=null && newUserList.length>0\">\r\n                            <tr *ngFor=\"let item of newUserList \">\r\n                                <th scope=\"row\">\r\n                                    {{item.s_no}}.\r\n                                </th>\r\n                                <td>\r\n                                    {{item.name}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.phone_no}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.company_name}}\r\n                                </td>\r\n                                <td>\r\n                                    <button (click)=\"onActiveClick(item.id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-user-check\"></i></button>\r\n                                    <button (click)=\"onRejectClick(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-user-times\"></i></button>\r\n                                </td>\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"newUserList==undefined || newUserList.length==0\" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/product-list/product-list.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/product-list/product-list.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n</div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">All Products</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\">\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\"><i class=\"ni ni-image\"></i></th>\r\n                                <th scope=\"col\">Product name</th>\r\n                                <th scope=\"col\">Category</th>\r\n                                <th scope=\"col\">Sub Category</th>\r\n                                <th scope=\"col\">Quantity</th>\r\n                                <th scope=\"col\">Price</th>\r\n                                <th scope=\"col\">Action</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"productList!=undefined\">\r\n                            <tr *ngFor=\"let item of productList; let i=index\">\r\n                                <th scope=\"row\">\r\n                                    {{i+1}}\r\n                                </th>\r\n                                <td>\r\n                                    <img [src]=\"item.imageurl || 'http://placehold.it/180'\" width=\"150px\" *ngIf=\"item.imageurl!=''\">\r\n                                </td>\r\n                                <td>\r\n                                    {{item.itemName}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.categoryName}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.subcategoryName}}\r\n                                </td>\r\n                                <td>\r\n                                    <div *ngIf=\"item.EditionType!=0 && item.Edition!=undefined\">\r\n                                        <div class=\"row\" *ngFor=\"let edition of item.Edition\">\r\n                                            <div class=\"col-6\">{{edition.itemEditionName}}: </div>\r\n                                            <div class=\"col-6\">{{edition.quantity}}</div>\r\n                                        </div>\r\n\r\n                                    </div>\r\n                                    <div *ngIf=\"item.EditionType==0 && item.Edition!=undefined\">\r\n                                        {{item.Edition[0].quantity}}\r\n                                    </div>\r\n                                </td>\r\n                                <td>\r\n                                    <div *ngIf=\"item.EditionType!=0 && item.Edition!=undefined\">\r\n                                        <div class=\"row\" *ngFor=\"let edition of item.Edition\">\r\n                                            <div class=\"col-6\">{{edition.price}} KWD </div>\r\n                                        </div>\r\n\r\n                                    </div>\r\n                                    <div *ngIf=\"item.EditionType==0 && item.Edition!=undefined\">\r\n                                        {{item.Edition[0].price}} KWD\r\n                                    </div>\r\n\r\n                                </td>\r\n                                <td>\r\n                                    <button (click)=\"Edit(item.id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-pencil-alt\"></i></button>\r\n                                    <button (click)=\"Delete(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button>\r\n                                </td>\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"productList==undefined ||productList.length==0\" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sub-categories/sub-categories.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sub-categories/sub-categories.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n    <p style=\"color: white\">Please Wait. </p>  \r\n    </ngx-spinner> \r\n<div *ngIf=\"dataArray!=undefined\">\r\n    <app-overview [data]=\"dataArray\"></app-overview>\r\n  </div>\r\n<div class=\"container-fluid mt--7\">\r\n    <div class=\"row mt-5\">\r\n        <div class=\"col-xl-12 \">\r\n            <div class=\"card shadow\">\r\n                <div class=\"card-header border-0\">\r\n                    <div class=\"row align-items-center\">\r\n                        <div class=\"col\">\r\n                            <h3 class=\"mb-0\">Sub Categories</h3>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-responsive\">\r\n                    <!-- Projects table -->\r\n                    <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n                        <thead class=\"thead-light\">\r\n                            <tr>\r\n                                <th scope=\"col\">S.No</th>\r\n                                <th scope=\"col\">Category</th>\r\n                                <th scope=\"col\">Subcategory</th>\r\n                                <th scope=\"col\">Photo</th>\r\n                                <th scope=\"col\">Action</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody *ngIf=\"categoryList!=undefined && categoryList!=''\">\r\n                            <tr *ngFor=\"let item of categoryList\">\r\n                                <th scope=\"row\">\r\n                                    {{item.s_no}}\r\n                                </th>\r\n                                <td>\r\n                                    {{item.category_Name}}\r\n                                </td>\r\n                                <td>\r\n                                    {{item.Subcategory_name}}\r\n                                </td>\r\n                                <td>\r\n                                    <img [src]=\"item.photo\" width=\"150px\" >\r\n                                   \r\n                                </td>\r\n                                <td>\r\n                                    <button (click)=\"Editcategory(item.id)\" class=\"btn btn-sm btn-primary\"><i class=\"fas fa-pencil-alt\"></i></button>\r\n                                    <button (click)=\"Deletecategory(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"far fa-trash-alt\"></i></button>\r\n                                </td>\r\n                            </tr>\r\n                        </tbody>\r\n                    </table>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"categoryList==undefined ||categoryList.length==0\" style=\"text-align: center;\">\r\n                    <div class=\"col-xl-12\">\r\n                      <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n                    </div>\r\n                  </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-profile/user-profile.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-profile/user-profile.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ngx-spinner bdColor=\"rgba(51, 51, 51, 0.8)\" size=\"default\" type=\"ball-spin-clockwise\">  \r\n  <p style=\"color: white\">Please Wait. </p>  \r\n  </ngx-spinner> \r\n<div class=\"header pb-8 pt-5 pt-lg-8 d-flex align-items-center\"\r\n  style=\"min-height: 600px; background-image: url(assets/img/theme/profile-cover.jpg); background-size: cover; background-position: center top;\">\r\n  <!-- Mask -->\r\n  <span class=\"mask bg-gradient-danger opacity-8\"></span>\r\n  <!-- Header container -->\r\n  <div class=\"container-fluid d-flex align-items-center\">\r\n    <div class=\"row\">\r\n      <div class=\"col-lg-10 col-md-10\">\r\n        <h1 class=\"display-2 text-white\">Hello <br> Jain Hardware and power tools</h1>\r\n        <p class=\"text-white mt-0 mb-5\">You can update the Contact detail information from here. It will update in the\r\n          user application.</p>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"container-fluid mt--7\">\r\n  <div class=\"row\">\r\n    <div class=\"col-xl-4 order-xl-2 mb-5 mb-xl-0\">\r\n      <div class=\"card card-profile shadow\">\r\n        <div class=\"row justify-content-center\">\r\n          <div class=\"col-lg-3 order-lg-2\">\r\n            <div class=\"card-profile-image\">\r\n              <a href=\"javascript:void(0)\">\r\n                <img [src]=\"UserData.logo\" onerror=\"this.onerror=null;this.src='http://golden-handle.com/logo.png'\" >\r\n              </a>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"card-body pt-0 pt-md-4\">\r\n          <div class=\"row\">\r\n            <div class=\"col\">\r\n              <div class=\"card-profile-stats justify-content-center mt-md-7\">\r\n                <div class=\"text-center\">\r\n                  <h3>\r\n                    {{UserData.company_name}}\r\n                  </h3>\r\n                  <div class=\"h5 font-weight-300\">\r\n                    <i class=\"ni location_pin mr-2\"></i>\r\n                    Address : {{UserData.address1}} , {{UserData.city}}, {{UserData.country}}, {{UserData.postal_code}} <br/>\r\n                   <span>Contact No: {{UserData.phone_no}}</span> \r\n                  </div>\r\n                  <hr class=\"my-4\" />\r\n                  <p> {{UserData.about_us}}</p>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-xl-8 order-xl-1\">\r\n      <div class=\"card bg-secondary shadow\">\r\n        <div class=\"card-header bg-white border-0\">\r\n          <div class=\"row align-items-center\">\r\n            <div class=\"col-8\">\r\n              <h3 class=\"mb-0\">My account</h3>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"card-body\" *ngIf=\"UserData!=undefined\">\r\n        \r\n            <h6 class=\"heading-small text-muted mb-4\">User information</h6>\r\n            <div class=\"pl-lg-4\">\r\n              <div class=\"row\">\r\n                <div class=\"col-lg-6\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-email\">Email address</label>\r\n                    <input type=\"email\" id=\"input-email\" class=\"form-control form-control-alternative\"\r\n                      placeholder=\"jesse@example.com\"  [(ngModel)]=\"UserData.email\" (keyup)=\"onKeyEmail($event)\" disabled=true>\r\n                  </div>\r\n                </div>\r\n                <div class=\"col-lg-6\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-first-name\">Company name</label>\r\n                    <input type=\"text\" id=\"input-first-name\" class=\"form-control form-control-alternative\"\r\n                      placeholder=\"Company name\" value=\"Jain Hardware and power tools\" [(ngModel)]=\"UserData.company_name\" disabled=true>\r\n                  </div>\r\n                </div>\r\n              </div>  \r\n             \r\n                <div class=\"row\">\r\n                    <div class=\"col-lg-12 order-xl-3\">\r\n                        <div class=\"form-group\" *ngIf=\"imageShow==false\">\r\n                            <label class=\"form-control-label\" for=\"input-category\">Upload Logo Image</label>\r\n                            <input type=\"file\"  accept=\"image/*\" class=\"form-control form-control-alternative\"  (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload logo Image\" id=\"upload-image\">\r\n                        </div>\r\n                        <div class=\"form-group\" *ngIf=\"imageShow==true\">\r\n                            <div class=\"row\"> \r\n                                <div class=\"col-lg-5\"><img [src]=\"imagePath\" width=\"150px\" ></div>\r\n                                <div class=\"col-lg-7\">\r\n                                    <label class=\"form-control-label\" for=\"input-category\">Upload Logo Image</label>\r\n                                    <input type=\"file\"  accept=\"image/*\"  style=\"width: 300px;\" class=\"form-control form-control-alternative\"  (change)=\"handleFileInput($event.target.files)\" placeholder=\"Upload Logo Image\" id=\"upload-image\">\r\n\r\n                                </div>\r\n                          </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                      \r\n            </div>\r\n            <hr class=\"my-4\" />\r\n            <!-- Address -->\r\n            <h6 class=\"heading-small text-muted mb-4\">Contact information</h6>\r\n            <div class=\"pl-lg-4\">\r\n              <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-last-name\">Phone No</label>\r\n                    <input type=\"text\" id=\"input-last-name\" class=\"form-control form-control-alternative\"\r\n                      placeholder=\"123456789\"  [(ngModel)]=\"UserData.phone_no\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"col-md-12\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-last-name\">Phone No (optional)</label>\r\n                    <input type=\"text\" id=\"input-last-name\" class=\"form-control form-control-alternative\"\r\n                      placeholder=\"123456789\"  [(ngModel)]=\"UserData.phone_no2\">\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-address\">Address</label>\r\n                    <input id=\"input-address\" class=\"form-control form-control-alternative\" placeholder=\"Home Address\"\r\n                      value=\"Bld Mihail Kogalniceanu, nr. 8 Bl 1, Sc 1, Ap 09\" type=\"text\" [(ngModel)]=\"UserData.address1\">\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"row\">\r\n                <div class=\"col-lg-4\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-city\">City</label>\r\n                    <input type=\"text\" id=\"input-city\" class=\"form-control form-control-alternative\" placeholder=\"City\"\r\n                      value=\"Kuwait\" [(ngModel)]=\"UserData.city\" disabled=true>\r\n                  </div>\r\n                </div>\r\n                <div class=\"col-lg-4\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-country\">Country</label>\r\n                    <input type=\"text\" id=\"input-country\" class=\"form-control form-control-alternative\"\r\n                      placeholder=\"Country\" value=\"United States\" [(ngModel)]=\"UserData.country\" disabled=true>\r\n                  </div>\r\n                </div>\r\n                <div class=\"col-lg-4\">\r\n                  <div class=\"form-group\">\r\n                    <label class=\"form-control-label\" for=\"input-country\">Postal code</label>\r\n                    <input type=\"number\" id=\"input-postal-code\" class=\"form-control form-control-alternative\"\r\n                      placeholder=\"Postal code\" [(ngModel)]=\"UserData.postal_code\">\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <hr class=\"my-4\" />\r\n            <!-- Description -->\r\n            <h6 class=\"heading-small text-muted mb-4\">About me</h6>\r\n            <div class=\"pl-lg-4\">\r\n              <div class=\"form-group\">\r\n                <textarea rows=\"4\" class=\"form-control form-control-alternative\"\r\n                  placeholder=\"A few words about you ...\"  [(ngModel)]=\"UserData.about_us\"></textarea>\r\n              </div>\r\n            </div>\r\n            <div class=\"pl-lg-4 text-center\">\r\n              <button (click)=\"onSaveClick()\" class=\"btn btn-lg btn-block btn-primary\">Save</button>\r\n            </div>\r\n         \r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/users/users.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/users/users.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div *ngIf=\"dataArray!=undefined\">\r\n  <app-overview [data]=\"dataArray\"></app-overview>\r\n</div>\r\n<div class=\"container-fluid mt--7\">\r\n  <div class=\"row mt-5\">\r\n    <div class=\"col-xl-12 \">\r\n      <div class=\"card shadow\">\r\n        <div class=\"card-header border-0\">\r\n          <div class=\"row align-items-center\">\r\n            <div class=\"col\">\r\n              <h3 class=\"mb-0\">Registered Users</h3>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-responsive\">\r\n          <!-- Projects table -->\r\n          <table class=\"table align-items-center table-flush\" datatable [dtOptions]=\"dtOptions\" [dtTrigger]=\"dtTrigger\">\r\n            <thead class=\"thead-light\">\r\n              <tr>\r\n                <th scope=\"col\">S.No</th>\r\n                <th scope=\"col\">User Name</th>\r\n                <th scope=\"col\">Contact number</th>\r\n                <th scope=\"col\">Company name</th>\r\n                <th scope=\"col\">Action</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody  *ngIf=\"newUserList!=null && newUserList.length>0\">\r\n              <tr *ngFor=\"let item of newUserList ; let i=index\">\r\n                <th scope=\"row\">\r\n                  {{i+1}}.\r\n                </th>\r\n                <td>\r\n                  {{item.name}}\r\n                </td>\r\n                <td>\r\n                  {{item.phone_no}}\r\n                </td>\r\n                <td>\r\n                  {{item.company_name}}\r\n                </td>\r\n                <td>\r\n                  <!-- <a href=\"\" class=\"btn btn-sm btn-primary\">Active</a> -->\r\n                  <button (click)=\"onRejectClick(item.id)\" class=\"btn btn-sm btn-danger\"><i class=\"fas fa-ban\"></i></button>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"newUserList==undefined || newUserList.length==0\" style=\"text-align: center;\">\r\n          <div class=\"col-xl-12\">\r\n            <h3  style=\"text-align: center; padding: 2rem;\"> You don't have any data to show</h3>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>");

/***/ }),

/***/ "./src/app/components/overview/overview.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/overview/overview.component.css ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvb3ZlcnZpZXcvb3ZlcnZpZXcuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/components/overview/overview.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/overview/overview.component.ts ***!
  \***********************************************************/
/*! exports provided: OverviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OverviewComponent", function() { return OverviewComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var OverviewComponent = /** @class */ (function () {
    function OverviewComponent(router) {
        this.router = router;
    }
    OverviewComponent.prototype.ngOnChanges = function () {
        this.arrayData = this.data;
        if (this.arrayData != undefined) {
            this.pendingOrder = this.data['pendingOrder'];
            this.newUserCount = this.data['newUserCount'];
            this.RegisterUser = this.data['RegisterUser'];
            this.promotion = this.data['promotion'];
            this.conformorder = this.data['conformorder'];
        }
    };
    OverviewComponent.prototype.ngOnInit = function () {
    };
    OverviewComponent.prototype.linkclick = function (id) {
        if (id == 1) // pending order
         {
            this.router.navigate(["/pending_order"]);
        }
        else if (id == 2) // New users
         {
            this.router.navigate(["/pending_user"]);
        }
        else if (id == 3) //Accepted order
         {
            this.router.navigate(["/accepted_order"]);
        }
        else if (id == 4) // Running Offer
         {
            this.router.navigate(["/product_list"]);
        }
    };
    OverviewComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], OverviewComponent.prototype, "data", void 0);
    OverviewComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-overview',
            template: __importDefault(__webpack_require__(/*! raw-loader!./overview.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/overview/overview.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./overview.component.css */ "./src/app/components/overview/overview.component.css")).default]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], OverviewComponent);
    return OverviewComponent;
}());



/***/ }),

/***/ "./src/app/layouts/admin-layout/admin-layout.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/layouts/admin-layout/admin-layout.module.ts ***!
  \*************************************************************/
/*! exports provided: AdminLayoutModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLayoutModule", function() { return AdminLayoutModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var ngx_clipboard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-clipboard */ "./node_modules/ngx-clipboard/__ivy_ngcc__/fesm5/ngx-clipboard.js");
/* harmony import */ var _admin_layout_routing__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./admin-layout.routing */ "./src/app/layouts/admin-layout/admin-layout.routing.ts");
/* harmony import */ var _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pages/dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _pages_user_profile_user_profile_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../pages/user-profile/user-profile.component */ "./src/app/pages/user-profile/user-profile.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/__ivy_ngcc__/fesm5/ng-bootstrap.js");
/* harmony import */ var _pages_users_users_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../pages/users/users.component */ "./src/app/pages/users/users.component.ts");
/* harmony import */ var src_app_pages_pending_orders_pending_orders_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/pages/pending-orders/pending-orders.component */ "./src/app/pages/pending-orders/pending-orders.component.ts");
/* harmony import */ var src_app_pages_pending_users_pending_users_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/pages/pending-users/pending-users.component */ "./src/app/pages/pending-users/pending-users.component.ts");
/* harmony import */ var src_app_pages_all_orders_all_orders_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/pages/all-orders/all-orders.component */ "./src/app/pages/all-orders/all-orders.component.ts");
/* harmony import */ var src_app_pages_accepted_orders_accepted_orders_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/pages/accepted-orders/accepted-orders.component */ "./src/app/pages/accepted-orders/accepted-orders.component.ts");
/* harmony import */ var src_app_pages_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/pages/add-product/add-product.component */ "./src/app/pages/add-product/add-product.component.ts");
/* harmony import */ var src_app_pages_product_list_product_list_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/pages/product-list/product-list.component */ "./src/app/pages/product-list/product-list.component.ts");
/* harmony import */ var src_app_components_overview_overview_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/components/overview/overview.component */ "./src/app/components/overview/overview.component.ts");
/* harmony import */ var src_app_pages_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/pages/add-category/add-category.component */ "./src/app/pages/add-category/add-category.component.ts");
/* harmony import */ var src_app_pages_add_sub_category_add_sub_category_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/pages/add-sub-category/add-sub-category.component */ "./src/app/pages/add-sub-category/add-sub-category.component.ts");
/* harmony import */ var src_app_pages_categories_categories_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/pages/categories/categories.component */ "./src/app/pages/categories/categories.component.ts");
/* harmony import */ var src_app_pages_sub_categories_sub_categories_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/pages/sub-categories/sub-categories.component */ "./src/app/pages/sub-categories/sub-categories.component.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
/* harmony import */ var src_app_pages_add_offers_add_offers_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/pages/add-offers/add-offers.component */ "./src/app/pages/add-offers/add-offers.component.ts");
/* harmony import */ var src_app_pages_offers_list_offers_list_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/pages/offers-list/offers-list.component */ "./src/app/pages/offers-list/offers-list.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



























var AdminLayoutModule = /** @class */ (function () {
    function AdminLayoutModule() {
    }
    AdminLayoutModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(_admin_layout_routing__WEBPACK_IMPORTED_MODULE_6__["AdminLayoutRoutes"]),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClientModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__["NgbModule"],
                ngx_clipboard__WEBPACK_IMPORTED_MODULE_5__["ClipboardModule"],
                ngx_spinner__WEBPACK_IMPORTED_MODULE_22__["NgxSpinnerModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                angular_datatables__WEBPACK_IMPORTED_MODULE_23__["DataTablesModule"].forRoot(),
                _angular_material_dialog__WEBPACK_IMPORTED_MODULE_26__["MatDialogModule"]
            ],
            declarations: [
                _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["DashboardComponent"],
                _pages_user_profile_user_profile_component__WEBPACK_IMPORTED_MODULE_8__["UserProfileComponent"],
                _pages_users_users_component__WEBPACK_IMPORTED_MODULE_10__["UsersComponent"],
                src_app_pages_pending_orders_pending_orders_component__WEBPACK_IMPORTED_MODULE_11__["PendingOrdersComponent"],
                src_app_pages_pending_users_pending_users_component__WEBPACK_IMPORTED_MODULE_12__["PendingUsersComponent"],
                src_app_pages_all_orders_all_orders_component__WEBPACK_IMPORTED_MODULE_13__["AllOrdersComponent"],
                src_app_pages_accepted_orders_accepted_orders_component__WEBPACK_IMPORTED_MODULE_14__["AcceptedOrdersComponent"],
                src_app_pages_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_15__["AddProductComponent"],
                src_app_pages_product_list_product_list_component__WEBPACK_IMPORTED_MODULE_16__["ProductListComponent"],
                src_app_pages_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_18__["AddCategoryComponent"],
                src_app_pages_add_sub_category_add_sub_category_component__WEBPACK_IMPORTED_MODULE_19__["AddSubCategoryComponent"],
                src_app_pages_categories_categories_component__WEBPACK_IMPORTED_MODULE_20__["CategoriesComponent"],
                src_app_pages_sub_categories_sub_categories_component__WEBPACK_IMPORTED_MODULE_21__["SubCategoriesComponent"],
                src_app_components_overview_overview_component__WEBPACK_IMPORTED_MODULE_17__["OverviewComponent"],
                src_app_pages_add_offers_add_offers_component__WEBPACK_IMPORTED_MODULE_24__["AddOffersComponent"],
                src_app_pages_offers_list_offers_list_component__WEBPACK_IMPORTED_MODULE_25__["OffersListComponent"],
                _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["detailBox"]
            ]
        })
    ], AdminLayoutModule);
    return AdminLayoutModule;
}());



/***/ }),

/***/ "./src/app/layouts/admin-layout/admin-layout.routing.ts":
/*!**************************************************************!*\
  !*** ./src/app/layouts/admin-layout/admin-layout.routing.ts ***!
  \**************************************************************/
/*! exports provided: AdminLayoutRoutes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLayoutRoutes", function() { return AdminLayoutRoutes; });
/* harmony import */ var _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../pages/dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _pages_user_profile_user_profile_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../pages/user-profile/user-profile.component */ "./src/app/pages/user-profile/user-profile.component.ts");
/* harmony import */ var src_app_pages_users_users_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pages/users/users.component */ "./src/app/pages/users/users.component.ts");
/* harmony import */ var src_app_pages_pending_orders_pending_orders_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pages/pending-orders/pending-orders.component */ "./src/app/pages/pending-orders/pending-orders.component.ts");
/* harmony import */ var src_app_pages_pending_users_pending_users_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/pages/pending-users/pending-users.component */ "./src/app/pages/pending-users/pending-users.component.ts");
/* harmony import */ var src_app_pages_all_orders_all_orders_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pages/all-orders/all-orders.component */ "./src/app/pages/all-orders/all-orders.component.ts");
/* harmony import */ var src_app_pages_accepted_orders_accepted_orders_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/pages/accepted-orders/accepted-orders.component */ "./src/app/pages/accepted-orders/accepted-orders.component.ts");
/* harmony import */ var src_app_pages_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/pages/add-product/add-product.component */ "./src/app/pages/add-product/add-product.component.ts");
/* harmony import */ var src_app_pages_product_list_product_list_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/pages/product-list/product-list.component */ "./src/app/pages/product-list/product-list.component.ts");
/* harmony import */ var src_app_pages_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/pages/add-category/add-category.component */ "./src/app/pages/add-category/add-category.component.ts");
/* harmony import */ var src_app_pages_add_sub_category_add_sub_category_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/pages/add-sub-category/add-sub-category.component */ "./src/app/pages/add-sub-category/add-sub-category.component.ts");
/* harmony import */ var src_app_pages_categories_categories_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/pages/categories/categories.component */ "./src/app/pages/categories/categories.component.ts");
/* harmony import */ var src_app_pages_sub_categories_sub_categories_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/pages/sub-categories/sub-categories.component */ "./src/app/pages/sub-categories/sub-categories.component.ts");
/* harmony import */ var src_app_pages_add_offers_add_offers_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/pages/add-offers/add-offers.component */ "./src/app/pages/add-offers/add-offers.component.ts");
/* harmony import */ var src_app_pages_offers_list_offers_list_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/pages/offers-list/offers-list.component */ "./src/app/pages/offers-list/offers-list.component.ts");
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};















var AdminLayoutRoutes = [
    { path: 'dashboard', component: _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__["DashboardComponent"] },
    { path: 'user-profile', component: _pages_user_profile_user_profile_component__WEBPACK_IMPORTED_MODULE_1__["UserProfileComponent"] },
    { path: 'users', component: src_app_pages_users_users_component__WEBPACK_IMPORTED_MODULE_2__["UsersComponent"] },
    { path: 'pending_order', component: src_app_pages_pending_orders_pending_orders_component__WEBPACK_IMPORTED_MODULE_3__["PendingOrdersComponent"] },
    { path: 'pending_user', component: src_app_pages_pending_users_pending_users_component__WEBPACK_IMPORTED_MODULE_4__["PendingUsersComponent"] },
    { path: 'all_order', component: src_app_pages_all_orders_all_orders_component__WEBPACK_IMPORTED_MODULE_5__["AllOrdersComponent"] },
    { path: 'accepted_order', component: src_app_pages_accepted_orders_accepted_orders_component__WEBPACK_IMPORTED_MODULE_6__["AcceptedOrdersComponent"] },
    { path: 'add_product', component: src_app_pages_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_7__["AddProductComponent"] },
    { path: 'product_list', component: src_app_pages_product_list_product_list_component__WEBPACK_IMPORTED_MODULE_8__["ProductListComponent"] },
    { path: 'add_category', component: src_app_pages_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_9__["AddCategoryComponent"] },
    { path: 'add_sub_category', component: src_app_pages_add_sub_category_add_sub_category_component__WEBPACK_IMPORTED_MODULE_10__["AddSubCategoryComponent"] },
    { path: 'categories', component: src_app_pages_categories_categories_component__WEBPACK_IMPORTED_MODULE_11__["CategoriesComponent"] },
    { path: 'sub_categories', component: src_app_pages_sub_categories_sub_categories_component__WEBPACK_IMPORTED_MODULE_12__["SubCategoriesComponent"] },
    { path: 'add_offers', component: src_app_pages_add_offers_add_offers_component__WEBPACK_IMPORTED_MODULE_13__["AddOffersComponent"] },
    { path: 'offers_list', component: src_app_pages_offers_list_offers_list_component__WEBPACK_IMPORTED_MODULE_14__["OffersListComponent"] }
];


/***/ }),

/***/ "./src/app/pages/accepted-orders/accepted-orders.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/pages/accepted-orders/accepted-orders.component.css ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FjY2VwdGVkLW9yZGVycy9hY2NlcHRlZC1vcmRlcnMuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/accepted-orders/accepted-orders.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/accepted-orders/accepted-orders.component.ts ***!
  \********************************************************************/
/*! exports provided: AcceptedOrdersComponent, dialogbox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AcceptedOrdersComponent", function() { return AcceptedOrdersComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dialogbox", function() { return dialogbox; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var AcceptedOrdersComponent = /** @class */ (function () {
    function AcceptedOrdersComponent(auth, router, dialog, Spinner) {
        this.auth = auth;
        this.router = router;
        this.dialog = dialog;
        this.Spinner = Spinner;
        this.newUserList = [];
        this.OrderList = [];
        this.loading = false;
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.api_token = this.auth.getToken();
        this.getConformData();
    }
    AcceptedOrdersComponent.prototype.ngOnInit = function () {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        // this.setinterval=  setInterval(() => {
        //   this.getConformData(); 
        // }, 800000);
    };
    AcceptedOrdersComponent.prototype.ngOnDestroy = function () {
        // if( this.setinterval)
        // {
        //   clearInterval(this.setinterval);
        // }
        this.dtTrigger.unsubscribe();
    };
    AcceptedOrdersComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    AcceptedOrdersComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    AcceptedOrdersComponent.prototype.getConformData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getConformOrder(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                        _this.newUserList = res["data"]["newUserList"];
                        _this.OrderList = res["data"]["OrderList"];
                        //this.dtTrigger.next();
                    }
                }
            });
        }
    };
    AcceptedOrdersComponent.prototype.detailClick = function (id) {
        var _this = this;
        this.auth.getOrderDetail(this.api_token, id).subscribe(function (res) {
            if (res["status"] == 'success') {
                var dialogRef = _this.dialog.open(_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["detailBox"], {
                    width: '500px',
                    data: res["data"]
                });
                dialogRef.afterClosed().subscribe(function (result) {
                });
            }
        });
    };
    AcceptedOrdersComponent.prototype.onDeliveredClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Delivered Order", Message: "Are you sure this Order is Delivered!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            status: "delivered",
                            id: id
                        };
                        _this.auth.saveOrderStatus(data).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getConformData();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
            _this.loading = false;
        });
    };
    AcceptedOrdersComponent.prototype.onCancelClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Cancelled Order", Message: "Are you sure you want to Cancelled this Order!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            status: "cancelled",
                            id: id
                        };
                        _this.auth.saveOrderStatus(data).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getConformData();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    AcceptedOrdersComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"])
    ], AcceptedOrdersComponent.prototype, "dtElement", void 0);
    AcceptedOrdersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-accepted-orders',
            template: __importDefault(__webpack_require__(/*! raw-loader!./accepted-orders.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/accepted-orders/accepted-orders.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./accepted-orders.component.css */ "./src/app/pages/accepted-orders/accepted-orders.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"], ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"]])
    ], AcceptedOrdersComponent);
    return AcceptedOrdersComponent;
}());

var dialogbox = /** @class */ (function () {
    function dialogbox(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.conform = "conform";
    }
    dialogbox.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    dialogbox.prototype.onConformClick = function () {
        this.dialogRef.close(this.conform);
    };
    dialogbox.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"],] }] }
    ]; };
    dialogbox = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dialogbox.component',
            template: __importDefault(__webpack_require__(/*! raw-loader!../dialogbox/dialogbox.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/dialogbox.component.html")).default,
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"], Object])
    ], dialogbox);
    return dialogbox;
}());



/***/ }),

/***/ "./src/app/pages/add-category/add-category.component.css":
/*!***************************************************************!*\
  !*** ./src/app/pages/add-category/add-category.component.css ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkZC1jYXRlZ29yeS9hZGQtY2F0ZWdvcnkuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/add-category/add-category.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/add-category/add-category.component.ts ***!
  \**************************************************************/
/*! exports provided: AddCategoryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddCategoryComponent", function() { return AddCategoryComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/provider/message-box.service */ "./src/app/provider/message-box.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var fd = new FormData();
var AddCategoryComponent = /** @class */ (function () {
    function AddCategoryComponent(auth, router, aroute, Spinner, messageBox) {
        this.auth = auth;
        this.router = router;
        this.aroute = aroute;
        this.Spinner = Spinner;
        this.messageBox = messageBox;
        this.fileToUpload = "";
        this.category = "";
        this.imagePath = "";
        this.imageShow = false;
        this.id = 0;
        this.type = "add";
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
    }
    AddCategoryComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.aroute.queryParams
            .subscribe(function (params) {
            if (params["Id"] != undefined) {
                _this.id = params["Id"];
                _this.GetEditCategory(_this.id);
            }
            else {
                _this.id = 0;
                _this.GetEditCategory(_this.id);
            }
        });
        // this.setinterval=  setInterval(() => {
        //   this.gettopbardataData(); 
        // }, 5000);
    };
    AddCategoryComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
    };
    AddCategoryComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    AddCategoryComponent.prototype.handleFileInput = function (files) { this.fileToUpload = files.item(0); };
    AddCategoryComponent.prototype.saveCategory = function () {
        var _this = this;
        if (this.api_token != undefined && this.api_token != null && this.category != undefined && this.category != "") {
            this.Spinner.show();
            fd.append('image', this.fileToUpload);
            fd.append('api_token', this.api_token);
            fd.append('category', this.category);
            fd.append('type', this.type);
            fd.append('id', this.id);
            this.auth.saveCategory(fd).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == "success") {
                    var message = "Category Add Successfully";
                    if (_this.id != 0) {
                        message = "Category Update Successfully";
                    }
                    _this.DialogData = {
                        type: "Message",
                        Message: message
                    };
                    _this.messageBox.Show(_this.DialogData);
                }
            });
        }
    };
    AddCategoryComponent.prototype.GetEditCategory = function (categoryId) {
        var _this = this;
        this.id = categoryId;
        if (this.id != 0) {
            this.Spinner.show();
            if (this.api_token != null && this.api_token != undefined) {
                this.auth.getCategoryData(this.api_token, categoryId).subscribe(function (res) {
                    _this.Spinner.hide();
                    if (res["status"] == "success") {
                        _this.type = "edit";
                        _this.category = res["data"]['category_name'];
                        _this.imageShow = true;
                        _this.imagePath = res["data"]['photo'];
                    }
                });
            }
        }
        else {
            this.type = "add";
            this.category = "";
            this.imageShow = false;
            this.imagePath = "";
            this.Spinner.hide();
        }
    };
    AddCategoryComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] },
        { type: src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__["MessageBoxService"] }
    ]; };
    AddCategoryComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-category',
            template: __importDefault(__webpack_require__(/*! raw-loader!./add-category.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-category/add-category.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./add-category.component.css */ "./src/app/pages/add-category/add-category.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"], src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__["MessageBoxService"]])
    ], AddCategoryComponent);
    return AddCategoryComponent;
}());



/***/ }),

/***/ "./src/app/pages/add-offers/add-offers.component.css":
/*!***********************************************************!*\
  !*** ./src/app/pages/add-offers/add-offers.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkZC1vZmZlcnMvYWRkLW9mZmVycy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/add-offers/add-offers.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/add-offers/add-offers.component.ts ***!
  \**********************************************************/
/*! exports provided: AddOffersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddOffersComponent", function() { return AddOffersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/__ivy_ngcc__/fesm5/ng-bootstrap.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/provider/message-box.service */ "./src/app/provider/message-box.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var AddOffersComponent = /** @class */ (function () {
    function AddOffersComponent(auth, router, aroute, Spinner, messageBox, calendar, formatter) {
        this.auth = auth;
        this.router = router;
        this.aroute = aroute;
        this.Spinner = Spinner;
        this.messageBox = messageBox;
        this.calendar = calendar;
        this.formatter = formatter;
        this.dataArray = [];
        this.type = "percentage";
        this.hoveredDate = null;
        this.errormessageEnd = false;
        this.errormessagestart = false;
        this.id = 0;
        this.stype = "add";
        this.error = false;
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.startdate = calendar.getToday();
        this.enddate = calendar.getNext(calendar.getToday(), 'd', 1);
    }
    AddOffersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.aroute.queryParams
            .subscribe(function (params) {
            if (params["Id"] != undefined) {
                _this.id = params["Id"];
                _this.Getoffer(_this.id);
            }
            else {
                _this.id = 0;
                _this.Getoffer(_this.id);
                _this.code = _this.makeid(6);
            }
        });
        // this.setinterval=  setInterval(() => {
        //   this.gettopbardataData(); 
        // }, 50000);
    };
    AddOffersComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
    };
    AddOffersComponent.prototype.makeid = function (length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    };
    AddOffersComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    AddOffersComponent.prototype.datechange = function (e) {
        if (this.startdate != undefined) {
            debugger;
            this.errormessagestart = false;
            if (this.enddate != undefined) {
                this.errormessageEnd = false;
                var sd = this.startdate.month + "-" + this.startdate.day + "-" + this.startdate.year;
                var ed = this.enddate.month + "-" + this.enddate.day + "-" + this.enddate.year;
                var sdate = new Date(sd);
                var end = new Date(ed);
                if (sdate > end) {
                    this.errormessageEnd = true;
                }
                else {
                    this.errormessageEnd = false;
                }
            }
            else {
                this.errormessageEnd = true;
            }
        }
        else {
            this.errormessagestart = true;
        }
    };
    AddOffersComponent.prototype.checkvalid = function () {
        if (this.amount == undefined || this.amount == 0) {
            this.error = true;
            return false;
        }
        if (this.description == undefined || this.description.trim() == "") {
            this.error = true;
            return false;
        }
        this.error = false;
        return true;
    };
    AddOffersComponent.prototype.savechange = function () {
        var _this = this;
        this.error = false;
        if (this.errormessagestart != false && this.errormessageEnd != false && !this.checkvalid()) {
            this.error = true;
            return false;
        }
        var sd = new Date(this.startdate.month + "-" + this.startdate.day + "-" + this.startdate.year);
        var ed = new Date(this.enddate.month + "-" + this.enddate.day + "-" + this.enddate.year);
        var data = {
            amount: this.amount,
            code: this.code,
            description: this.description == undefined ? "" : this.description,
            type: this.type,
            minOrderAmount: this.minamount == undefined ? 0 : this.minamount,
            maxDiscountAmount: this.maxamount == undefined ? 0 : this.maxamount,
            start_date: sd,
            end_date: ed,
            api_token: this.api_token,
            id: this.id,
            stype: this.stype
        };
        this.auth.saveoffers(data).subscribe(function (res) {
            _this.Spinner.hide();
            if (res["status"] == "success") {
                var message = "Offers Add Successfully";
                if (_this.id != 0) {
                    message = "Offers Update Successfully";
                }
                _this.DialogData = {
                    type: "Message",
                    Message: message
                };
                _this.messageBox.Show(_this.DialogData);
            }
        });
    };
    AddOffersComponent.prototype.Getoffer = function (offerid) {
        var _this = this;
        this.id = offerid;
        if (this.id != 0) {
            this.Spinner.show();
            if (this.api_token != null && this.api_token != undefined) {
                this.auth.getoffersdata(this.api_token, offerid).subscribe(function (res) {
                    _this.Spinner.hide();
                    if (res["status"] == "success") {
                        _this.stype = "edit";
                        var sd = new Date(res["data"]['start_date']);
                        var Esd = new Date(res["data"]['end_date']);
                        _this.startdate = { day: sd.getDate(), month: sd.getMonth() + 1, year: sd.getFullYear() };
                        _this.enddate = { day: Esd.getDate(), month: Esd.getMonth() + 1, year: Esd.getFullYear() };
                        _this.type = res["data"]['type'];
                        _this.amount = res["data"]['amount'];
                        _this.minamount = res["data"]['minOrderAmount'];
                        _this.maxamount = res["data"]['maxDiscountAmount'];
                        _this.description = res["data"]['description'];
                        _this.code = res["data"]['code'];
                        console.log(sd);
                    }
                });
            }
        }
        else {
            this.startdate = this.calendar.getToday();
            this.enddate = this.calendar.getNext(this.calendar.getToday(), 'd', 1);
            this.type = "percentage";
            this.amount = "";
            this.minamount = "";
            this.maxamount = "";
            this.description = "";
            this.Spinner.hide();
            this.stype = "add";
        }
    };
    AddOffersComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"] },
        { type: src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_5__["MessageBoxService"] },
        { type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbCalendar"] },
        { type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbDateParserFormatter"] }
    ]; };
    AddOffersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-offers',
            template: __importDefault(__webpack_require__(/*! raw-loader!./add-offers.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-offers/add-offers.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./add-offers.component.css */ "./src/app/pages/add-offers/add-offers.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"], src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_5__["MessageBoxService"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbCalendar"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbDateParserFormatter"]])
    ], AddOffersComponent);
    return AddOffersComponent;
}());



/***/ }),

/***/ "./src/app/pages/add-product/add-product.component.css":
/*!*************************************************************!*\
  !*** ./src/app/pages/add-product/add-product.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkZC1wcm9kdWN0L2FkZC1wcm9kdWN0LmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/add-product/add-product.component.ts":
/*!************************************************************!*\
  !*** ./src/app/pages/add-product/add-product.component.ts ***!
  \************************************************************/
/*! exports provided: AddProductComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddProductComponent", function() { return AddProductComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/provider/message-box.service */ "./src/app/provider/message-box.service.ts");
/* harmony import */ var _message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../message-box/message-box.component */ "./src/app/pages/message-box/message-box.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var fd = new FormData();
var AddProductComponent = /** @class */ (function () {
    function AddProductComponent(auth, router, aroute, Spinner, messageBox, dialog) {
        this.auth = auth;
        this.router = router;
        this.aroute = aroute;
        this.Spinner = Spinner;
        this.messageBox = messageBox;
        this.dialog = dialog;
        this.categoryId = 0;
        this.SubcategoryId = 0;
        this.multipleSub = false;
        this.showEditopnAddmore = false;
        this.EditionList = [];
        this.ShowEditiontable = false;
        this.price = 0.0;
        this.quantity = 0;
        this.showErrorEdition = false;
        this.editionid = 0;
        this.RemoveNode = [];
        this.showEdError = false;
        this.fileToUpload = [];
        this.Pid = 0;
        this.descritption = "";
        this.ImageType = "Select";
        this.imageGrid = [];
        this.showImageGrid = false;
        this.Removeimage = [];
        this.showMainImage = true;
        this.showImageError = false;
        this.addtionbutton = "Add";
        this.showError = false;
        this.additionList = [];
        this.ShowEditionGrid = false;
        this.infoid = 0;
        this.RemoveInfo = [];
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.GetCategoryList();
        //this.GetProductDetail(11);
    }
    AddProductComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.aroute.queryParams
            .subscribe(function (params) {
            if (params["Id"] != undefined) {
                _this.Pid = params["Id"];
                _this.GetProductDetail(_this.Pid);
            }
            else {
                _this.Pid = 0;
                _this.GetProductDetail(_this.Pid);
            }
        });
        // this.setinterval=  setInterval(() => {
        //   this.gettopbardataData(); 
        // }, 5000);
    };
    AddProductComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
    };
    AddProductComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    AddProductComponent.prototype.GetCategoryList = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getCategoryList(this.api_token).subscribe(function (res) {
                _this.categoryList = "";
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.categoryList = res["data"];
                    }
                }
            });
        }
    };
    AddProductComponent.prototype.categorychange = function () {
        var _this = this;
        if (this.categoryId != 0 && this.categoryId != undefined) {
            this.auth.getSubCategoryId(this.api_token, this.categoryId).subscribe(function (res) {
                console.log(res);
                _this.subCategoryList = "";
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.subCategoryList = res["data"];
                    }
                    else {
                        _this.subCategoryList = [];
                    }
                }
                else {
                    _this.subCategoryList = [];
                }
            });
        }
    };
    AddProductComponent.prototype.SelectMultie = function () {
        if (this.multipleSub == true) {
            this.EditionName = "";
            this.showEditopnAddmore = true;
        }
        else {
            this.EditionName = this.productName;
            this.showEditopnAddmore = false;
            this.ShowEditiontable = false;
        }
    };
    AddProductComponent.prototype.AddName = function () {
        if (this.multipleSub == true) {
            this.EditionName = "";
        }
        else {
            this.EditionName = this.productName;
        }
    };
    AddProductComponent.prototype.AddMoreEdition = function () {
        var _this = this;
        if (this.checkEdition() == true) {
            if (this.editionid == 0) {
                var data = {
                    EditionName: this.EditionName,
                    price: this.price,
                    quantity: this.quantity,
                    remark: this.remark,
                    id: this.editionid
                };
                this.EditionList.push(data);
                this.editionid = 0;
                this.EditionName = "";
                this.price = 0;
                this.quantity = 0;
                this.remark = "";
            }
            else {
                this.EditionList.forEach(function (element) {
                    if (element.id == _this.editionid) {
                        element.EditionName = _this.EditionName;
                        element.price = _this.price;
                        element.quantity = _this.quantity;
                        element.remark = _this.remark;
                    }
                });
                this.editionid = 0;
                this.EditionName = "";
                this.price = 0;
                this.quantity = 0;
                this.remark = "";
            }
            this.ShowEditiontable = true;
        }
    };
    AddProductComponent.prototype.checkEdition = function () {
        if (this.EditionName.trim() != "" && this.EditionName != undefined && this.price != 0 && this.price != undefined && this.quantity != undefined) {
            this.showErrorEdition = false;
            return true;
        }
        else {
            this.showErrorEdition = true;
            return false;
        }
    };
    AddProductComponent.prototype.editEdition = function (Item) {
        this.editionid = Item.id;
        this.EditionName = Item.EditionName;
        this.price = Item.price;
        this.quantity = Item.quantity;
        this.remark = Item.remark;
    };
    AddProductComponent.prototype.DeleteEdition = function (item) {
        this.EditionList = this.EditionList.filter(function (_a) {
            var EditionName = _a.EditionName;
            return EditionName !== item.EditionName;
        });
        if (item.id != 0) {
            this.RemoveNode.push(item.id);
        }
    };
    AddProductComponent.prototype.CheckName = function () {
        if (this.multipleSub == true) {
            if (this.EditionName == this.productName) {
                this.showEdError = true;
            }
            else {
                this.showEdError = false;
            }
        }
        else {
            this.showEdError = false;
        }
    };
    AddProductComponent.prototype.handleFileInput = function (files) {
        var _this = this;
        if (this.ImageType != "Select") {
            var filedata = files[0];
            var reader_1 = new FileReader();
            reader_1.readAsDataURL(filedata);
            reader_1.onload = function (e) {
                _this.imageSrc = reader_1.result;
                console.log(_this.imageGrid.length);
                if (_this.imageGrid.length > 0) {
                    console.log(_this.imageGrid);
                    console.log(_this.ImageType);
                    if (_this.ImageType == "Main") {
                        var maindata = _this.imageGrid.find(function (x) { return x.image_type === "Main"; });
                        if (maindata != null) {
                            _this.saveproductImages(files.item(0), _this.imageSrc, 1);
                        }
                        else {
                            _this.saveproductImages(files.item(0), _this.imageSrc, 0);
                        }
                    }
                    else {
                        _this.saveproductImages(files.item(0), _this.imageSrc, 0);
                        ;
                    }
                }
                else {
                    _this.saveproductImages(files.item(0), _this.imageSrc, 0);
                    ;
                }
            };
            this.showImageError = false;
            this.showImageGrid = true;
            if (this.ImageType == 'Main') {
                this.showMainImage = false;
            }
        }
        else {
            this.showImageError = true;
        }
    };
    AddProductComponent.prototype.saveproductImages = function (files, imageSrc, type) {
        var _this = this;
        this.Spinner.show();
        var fd1 = new FormData;
        fd1.append('api_token', this.api_token);
        fd1.append('image', files);
        this.auth.postProductImage(fd1).subscribe(function (x) {
            _this.Spinner.hide();
            if (x["status"] == "success") {
                if (type == 1) {
                    _this.imageGrid.forEach(function (element) {
                        if (element.image_type == "Main") {
                            element.imageUrl = x["data"]["imagepath"];
                            element.imageName = x["data"]["imageName"];
                        }
                    });
                }
                else {
                    var data = {
                        image_type: _this.ImageType,
                        imageUrl: x["data"]["imagepath"],
                        imageName: x["data"]["imageName"],
                        id: 0
                    };
                    _this.imageGrid.push(data);
                }
            }
        });
    };
    AddProductComponent.prototype.DeleteImage = function (item, index) {
        // this.imageGrid = this.imageGrid.filter((_, index) => index !== index);
        if (item.image_type == 'Main') {
            this.showMainImage = true;
        }
        if (item.id != 0) {
            this.Removeimage.push(item.id);
        }
        this.imageGrid.splice(index, 1);
    };
    AddProductComponent.prototype.AddAditioninfo = function () {
        var _this = this;
        if (this.AddValue != undefined && this.AddValue.trim() != null) {
            if (this.infoid == 0) {
                this.addtionbutton = "Add More";
                this.showError = true;
                var data = {
                    id: this.infoid,
                    key: this.AddKey,
                    value: this.AddValue
                };
                this.additionList.push(data);
            }
            else {
                this.additionList.forEach(function (element) {
                    if (_this.infoid == element.id) {
                        element.key = _this.AddKey;
                        element.value = _this.AddValue;
                    }
                });
            }
            this.ShowEditionGrid = true;
            this.infoid = 0;
            this.AddKey = "";
            this.AddValue = "";
        }
        else {
            this.showError = true;
        }
    };
    AddProductComponent.prototype.editinfo = function (Item) {
        this.infoid = Item.id;
        this.AddKey = Item.key;
        this.AddValue = Item.value;
    };
    AddProductComponent.prototype.Deleteinfo = function (item, index) {
        if (item.id != 0) {
            this.RemoveInfo.push(item.id);
        }
        this.additionList.splice(index, 1);
    };
    AddProductComponent.prototype.checkentry = function () {
        if (this.categoryId != 0 && this.productName != undefined && this.productName.trim() != "") {
            if (this.multipleSub == false) {
                if (this.price != 0) {
                    return true;
                }
                else {
                    if (this.EditionList.length > 0) {
                        return true;
                    }
                }
            }
            else {
                if (this.EditionList.length > 0) {
                    return true;
                }
            }
        }
        return false;
    };
    AddProductComponent.prototype.saveproduct = function () {
        this.Spinner.show();
        if (this.checkentry()) {
            var data = {
                api_token: this.api_token,
                categoryId: this.categoryId,
                subCategoryId: this.SubcategoryId,
                id: this.Pid,
                ProductName: this.productName,
                EditionType: this.multipleSub,
                Description: this.descritption == undefined ? "" : this.descritption,
                price: this.price,
                quantity: this.quantity,
                remark: this.remark == undefined ? "" : this.remark,
                editionList: this.EditionList,
                imageList: this.imageGrid,
                additionList: this.additionList,
                RemoveImage: this.Removeimage,
                removeEdition: this.RemoveNode,
                removeAdditions: this.RemoveInfo,
                editionId: this.editionid,
                editionName: this.EditionName,
            };
            if (this.additionList.length == 0) {
                var value = this.AddValue == undefined ? "" : this.AddValue;
                if (value.trim() != "") {
                    this.Spinner.hide();
                    var dialogRef = this.dialog.open(_message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__["MessageBoxComponent"], {
                        width: '500px',
                        data: { type: "Warning", Message: "Please add or remove additional information" }
                    });
                    dialogRef.afterClosed().subscribe(function (result) {
                        if (result != undefined) {
                            if (result == "conform") {
                                return;
                            }
                        }
                    });
                }
                else {
                    this.saveApiCalled(data);
                }
            }
            else if (this.additionList.length > 0) {
                var value = this.AddValue == undefined ? "" : this.AddValue;
                if (value.trim() != "") {
                    this.Spinner.hide();
                    var dialogRef = this.dialog.open(_message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__["MessageBoxComponent"], {
                        width: '500px',
                        data: { type: "Warning", Message: "Please add or remove additional information" }
                    });
                    dialogRef.afterClosed().subscribe(function (result) {
                        if (result != undefined) {
                            if (result == "conform") {
                                return;
                            }
                        }
                    });
                }
                else {
                    this.saveApiCalled(data);
                }
            }
            else {
                this.saveApiCalled(data);
            }
        }
        else {
            this.Spinner.hide();
        }
    };
    AddProductComponent.prototype.saveApiCalled = function (data) {
        var _this = this;
        this.auth.postProduct(data).subscribe(function (x) {
            _this.Spinner.hide();
            if (x["status"] == "success") {
                var message = "Product Add Successfully";
                if (_this.Pid != 0) {
                    message = "Product Update Successfully";
                }
                _this.DialogData = {
                    type: "Message",
                    Message: message
                };
                _this.messageBox.Show(_this.DialogData);
                // this.router.navigate(["/product_list"]);
            }
        });
    };
    AddProductComponent.prototype.GetProductDetail = function (id) {
        var _this = this;
        this.Pid = id;
        this.Spinner.show();
        if (this.Pid != 0) {
            this.auth.getProductDataId(this.api_token, id).subscribe(function (x) {
                _this.Spinner.hide();
                if (x["status"] == "success") {
                    if (x["data"] != "") {
                        _this.categoryId = +x["data"]["itemDetail"]["category_id"];
                        _this.SubcategoryId = +x["data"]["itemDetail"]["subcategory_id"];
                        _this.categorychange();
                        _this.productName = x["data"]["itemDetail"]["itemName"];
                        _this.multipleSub = x["data"]["itemDetail"]["EditionType"] == 0 ? false : true;
                        _this.descritption = x["data"]["itemDetail"]["aboutItem"];
                        if (_this.multipleSub == false) {
                            _this.price = x["data"]["itemedition"][0]["price"];
                            _this.quantity = x["data"]["itemedition"][0]["quantity"];
                            _this.remark = x["data"]["itemedition"][0]["remark"];
                            _this.editionid = x["data"]["itemedition"][0]["id"];
                            _this.EditionName = x["data"]["itemedition"][0]["itemEditionName"];
                        }
                        else {
                            _this.ShowEditiontable = true;
                            _this.showEditopnAddmore = true;
                            x["data"]["itemedition"].forEach(function (element) {
                                var data = {
                                    price: element.price,
                                    quantity: element.quantity,
                                    Remark: element.remark,
                                    id: element.id,
                                    EditionName: element.itemEditionName
                                };
                                _this.EditionList.push(data);
                            });
                        }
                        if (x["data"]["itemImage"] != "" && x["data"]["itemImage"] != null) {
                            _this.showImageGrid = true;
                            x["data"]["itemImage"].forEach(function (element) {
                                var data = {
                                    image_type: element.type,
                                    imageUrl: element.imageURL,
                                    imageName: element.imageURL,
                                    id: element.id
                                };
                                _this.imageGrid.push(data);
                            });
                        }
                        if (x["data"]["itemInfo"] != "" && x["data"]["itemInfo"] != null) {
                            _this.ShowEditionGrid = true;
                            x["data"]["itemInfo"].forEach(function (element) {
                                var data = {
                                    key: element.AttributeKey,
                                    value: element.AttributeValue,
                                    id: element.id
                                };
                                _this.additionList.push(data);
                            });
                        }
                    }
                }
            });
        }
        else {
            this.Spinner.hide();
            this.categoryId = 0;
            this.SubcategoryId = 0;
            this.subCategoryList = [];
            this.productName = "";
            this.multipleSub = false;
            this.descritption = "";
            this.ShowEditionGrid = false;
            this.additionList = [];
            this.showImageGrid = false;
            this.imageGrid = [];
            this.ShowEditiontable = false;
            this.showEditopnAddmore = false;
            this.EditionList = [];
            this.price = 0;
            this.quantity = 0;
            this.remark = "";
            this.editionid = 0;
            this.EditionName = "";
        }
    };
    AddProductComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] },
        { type: src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__["MessageBoxService"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"] }
    ]; };
    AddProductComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-product',
            template: __importDefault(__webpack_require__(/*! raw-loader!./add-product.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-product/add-product.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./add-product.component.css */ "./src/app/pages/add-product/add-product.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"], src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__["MessageBoxService"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]])
    ], AddProductComponent);
    return AddProductComponent;
}());



/***/ }),

/***/ "./src/app/pages/add-sub-category/add-sub-category.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/pages/add-sub-category/add-sub-category.component.css ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkZC1zdWItY2F0ZWdvcnkvYWRkLXN1Yi1jYXRlZ29yeS5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/add-sub-category/add-sub-category.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pages/add-sub-category/add-sub-category.component.ts ***!
  \**********************************************************************/
/*! exports provided: AddSubCategoryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSubCategoryComponent", function() { return AddSubCategoryComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/provider/message-box.service */ "./src/app/provider/message-box.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var fd = new FormData();
var AddSubCategoryComponent = /** @class */ (function () {
    function AddSubCategoryComponent(auth, router, aroute, Spinner, messageBox) {
        this.auth = auth;
        this.router = router;
        this.aroute = aroute;
        this.Spinner = Spinner;
        this.messageBox = messageBox;
        this.categoryId = 0;
        this.type = 'add';
        this.id = 0;
        this.fileToUpload = "";
        this.imagePath = "";
        this.imageShow = false;
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.GetCategoryList();
    }
    AddSubCategoryComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.aroute.queryParams
            .subscribe(function (params) {
            if (params["Id"] != undefined) {
                _this.id = params["Id"];
                _this.GetEditCategory(_this.id);
            }
            else {
                _this.id = 0;
                _this.GetEditCategory(_this.id);
            }
        });
        // this.setinterval=  setInterval(() => {
        //   this.gettopbardataData(); 
        // }, 5000);
    };
    AddSubCategoryComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
    };
    AddSubCategoryComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    AddSubCategoryComponent.prototype.GetCategoryList = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getCategoryList(this.api_token).subscribe(function (res) {
                _this.categoryList = "";
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.categoryList = res["data"];
                        console.log(res["data"]);
                    }
                }
            });
        }
    };
    AddSubCategoryComponent.prototype.handleFileInput = function (files) { this.fileToUpload = files.item(0); };
    AddSubCategoryComponent.prototype.saveSubCategory = function () {
        var _this = this;
        if (this.categoryId != 0 && this.SubcategoryName != null && this.SubcategoryName != undefined) {
            this.Spinner.show();
            fd.append('image', this.fileToUpload);
            fd.append('api_token', this.api_token);
            fd.append('Subcategory', this.SubcategoryName);
            fd.append('type', this.type);
            fd.append('id', this.id);
            fd.append('category_id', this.categoryId);
            // let data= {
            //   api_token:this.api_token,
            //   type:this.type,
            //   Subcategory:this.SubcategoryName,
            //   category_id:this.categoryId,
            //   id:this.id
            // }
            this.auth.saveSubCategory(fd).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == "success") {
                    var message = "Sub category Add Successfully";
                    if (_this.id != 0) {
                        message = "Sub category Update Successfully";
                    }
                    _this.DialogData = {
                        type: "Message",
                        Message: message
                    };
                    _this.messageBox.Show(_this.DialogData);
                    //this.router.navigate(["/sub_categories"]);
                }
            });
        }
    };
    AddSubCategoryComponent.prototype.GetEditCategory = function (categoryId) {
        var _this = this;
        this.Spinner.show();
        this.id = categoryId;
        if (this.id != 0) {
            if (this.api_token != null && this.api_token != undefined) {
                this.Spinner.hide();
                this.auth.getSubCategoryData(this.api_token, categoryId).subscribe(function (res) {
                    if (res["status"] == "success") {
                        _this.type = "edit";
                        _this.SubcategoryName = res["data"]['category_name'];
                        _this.categoryId = res["data"]['category_id'];
                        _this.imageShow = true;
                        _this.imagePath = res["data"]['photo'];
                    }
                });
            }
        }
        else {
            this.type = "add";
            this.SubcategoryName = "";
            this.categoryId = 0;
            this.imageShow = false;
            this.imagePath = "";
            this.Spinner.hide();
        }
    };
    AddSubCategoryComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] },
        { type: src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__["MessageBoxService"] }
    ]; };
    AddSubCategoryComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-sub-category',
            template: __importDefault(__webpack_require__(/*! raw-loader!./add-sub-category.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-sub-category/add-sub-category.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./add-sub-category.component.css */ "./src/app/pages/add-sub-category/add-sub-category.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"], src_app_provider_message_box_service__WEBPACK_IMPORTED_MODULE_4__["MessageBoxService"]])
    ], AddSubCategoryComponent);
    return AddSubCategoryComponent;
}());



/***/ }),

/***/ "./src/app/pages/all-orders/all-orders.component.css":
/*!***********************************************************!*\
  !*** ./src/app/pages/all-orders/all-orders.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FsbC1vcmRlcnMvYWxsLW9yZGVycy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/all-orders/all-orders.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/all-orders/all-orders.component.ts ***!
  \**********************************************************/
/*! exports provided: AllOrdersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllOrdersComponent", function() { return AllOrdersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var AllOrdersComponent = /** @class */ (function () {
    function AllOrdersComponent(auth, router, dialog, Spinner) {
        this.auth = auth;
        this.router = router;
        this.dialog = dialog;
        this.Spinner = Spinner;
        this.newUserList = [];
        this.OrderList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.api_token = this.auth.getToken();
        this.getDeliveredData();
    }
    AllOrdersComponent.prototype.ngOnInit = function () {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 2
        };
        // this.setinterval=  setInterval(() => {
        //   this.getDeliveredData(); 
        // }, 80000);
    };
    AllOrdersComponent.prototype.ngOnDestroy = function () {
        // if( this.setinterval)
        // {
        //   clearInterval(this.setinterval);
        // }
        this.dtTrigger.unsubscribe();
    };
    AllOrdersComponent.prototype.getDeliveredData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getDeliveredOrder(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                        _this.newUserList = res["data"]["newUserList"];
                        _this.OrderList = res["data"]["OrderList"];
                        _this.dtTrigger.next();
                    }
                }
            });
        }
    };
    AllOrdersComponent.prototype.detailClick = function (id) {
        var _this = this;
        this.auth.getOrderDetail(this.api_token, id).subscribe(function (res) {
            if (res["status"] == 'success') {
                console.log(res["data"]);
                var data = res["data"];
                var dialogRef = _this.dialog.open(_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__["detailBox"], {
                    width: '500px',
                    data: res["data"]
                });
                dialogRef.afterClosed().subscribe(function (result) {
                });
            }
        });
    };
    AllOrdersComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"] }
    ]; };
    AllOrdersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-all-orders',
            template: __importDefault(__webpack_require__(/*! raw-loader!./all-orders.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/all-orders/all-orders.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./all-orders.component.css */ "./src/app/pages/all-orders/all-orders.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"], ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"]])
    ], AllOrdersComponent);
    return AllOrdersComponent;
}());



/***/ }),

/***/ "./src/app/pages/categories/categories.component.css":
/*!***********************************************************!*\
  !*** ./src/app/pages/categories/categories.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NhdGVnb3JpZXMvY2F0ZWdvcmllcy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/categories/categories.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/categories/categories.component.ts ***!
  \**********************************************************/
/*! exports provided: CategoriesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoriesComponent", function() { return CategoriesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../message-box/message-box.component */ "./src/app/pages/message-box/message-box.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var CategoriesComponent = /** @class */ (function () {
    function CategoriesComponent(auth, router, Spinner, dialog) {
        this.auth = auth;
        this.router = router;
        this.Spinner = Spinner;
        this.dialog = dialog;
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.GetCategoryList();
    }
    CategoriesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        this.setinterval = setInterval(function () {
            _this.gettopbardataData();
        }, 800000);
    };
    CategoriesComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
        this.dtTrigger.unsubscribe();
    };
    CategoriesComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    CategoriesComponent.prototype.GetCategoryList = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getCategoryList(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                _this.categoryList = "";
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.categoryList = res["data"];
                        // this.dtTrigger.next();
                    }
                }
            });
        }
    };
    CategoriesComponent.prototype.Editcategory = function (id) {
        this.router.navigate(["/add_category"], { queryParams: { Id: id } });
    };
    CategoriesComponent.prototype.Deletecategory = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(_message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__["MessageBoxComponent"], {
            width: '500px',
            data: { type: "Delete", Message: "Are you sure you want to Delete!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            type: "delete",
                            id: id
                        };
                        _this.auth.postCategoryDelete(data).subscribe(function (res) {
                            if (res["status"] == 'success') {
                                _this.GetCategoryList();
                            }
                        });
                    }
                }
            }
        });
    };
    CategoriesComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    CategoriesComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    CategoriesComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_7__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_7__["DataTableDirective"])
    ], CategoriesComponent.prototype, "dtElement", void 0);
    CategoriesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-categories',
            template: __importDefault(__webpack_require__(/*! raw-loader!./categories.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/categories/categories.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./categories.component.css */ "./src/app/pages/categories/categories.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]])
    ], CategoriesComponent);
    return CategoriesComponent;
}());



/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rhc2hib2FyZC9kYXNoYm9hcmQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.component.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.ts ***!
  \********************************************************/
/*! exports provided: DashboardComponent, dialogbox, detailBox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dialogbox", function() { return dialogbox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detailBox", function() { return detailBox; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var DashboardComponent = /** @class */ (function () {
    function DashboardComponent(auth, router, dialog, Spinner) {
        this.auth = auth;
        this.router = router;
        this.dialog = dialog;
        this.Spinner = Spinner;
        this.newUserList = [];
        this.newOrderList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.dtOptionsU = {};
        this.dtTriggerU = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.api_token = this.auth.getToken();
        this.getDeshbordData();
    }
    DashboardComponent.prototype.ngOnInit = function () {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10
        };
        this.dtOptionsU = {
            pagingType: 'full_numbers',
            pageLength: 10
        };
    };
    DashboardComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
        this.dtTriggerU.next();
        //this.dtTrigger.next();
    };
    DashboardComponent.prototype.ngOnDestroy = function () {
        this.dtTrigger.unsubscribe();
        this.dtTriggerU.unsubscribe();
    };
    DashboardComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
            _this.dtTriggerU.next();
        });
    };
    DashboardComponent.prototype.getDeshbordData = function () {
        var _this = this;
        this.Spinner.show();
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getDeshboard(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        console.log(res["data"]);
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                        _this.newUserList = res["data"]["newUserList"];
                        _this.newOrderList = res["data"]["OrderList"];
                        //  this.dtTrigger.next();
                        //  this.dtTriggerU.next();
                    }
                }
            });
        }
        else {
            this.Spinner.hide();
        }
    };
    DashboardComponent.prototype.detailClick = function (id) {
        var _this = this;
        this.Spinner.show();
        this.auth.getOrderDetail(this.api_token, id).subscribe(function (res) {
            _this.Spinner.hide();
            if (res["status"] == 'success') {
                var dialogRef = _this.dialog.open(detailBox, {
                    width: '500px',
                    data: res["data"]
                });
                dialogRef.afterClosed().subscribe(function (result) {
                });
            }
        });
    };
    DashboardComponent.prototype.SeeAllOrdes = function () {
        this.router.navigate(["/pending_order"]);
    };
    DashboardComponent.prototype.seeallUsers = function () {
        this.router.navigate(["/users"]);
    };
    DashboardComponent.prototype.onActiveClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "active", Message: "Are you sure you want to active this user!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        _this.auth.saveUserStatus(_this.api_token, 'active', id).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getDeshbordData();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    DashboardComponent.prototype.onRejectClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Decline", Message: "Are you sure you want to Decline this user!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        _this.auth.saveUserStatus(_this.api_token, 'reject', id).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getDeshbordData();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    DashboardComponent.prototype.onConformClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Conform Order", Message: "Are you sure you want to Accept this Order!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            status: "conformed",
                            id: id
                        };
                        _this.auth.saveOrderStatus(data).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getDeshbordData();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    DashboardComponent.prototype.onCancelClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Cancelled Order", Message: "Are you sure you want to Cancelled this Order!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            status: "cancelled",
                            id: id
                        };
                        _this.auth.saveOrderStatus(data).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getDeshbordData();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    DashboardComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialog"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"])
    ], DashboardComponent.prototype, "dtElement", void 0);
    DashboardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dashboard',
            template: __importDefault(__webpack_require__(/*! raw-loader!./dashboard.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dashboard/dashboard.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./dashboard.component.scss */ "./src/app/pages/dashboard/dashboard.component.scss")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialog"], ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"]])
    ], DashboardComponent);
    return DashboardComponent;
}());

var dialogbox = /** @class */ (function () {
    function dialogbox(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.conform = "conform";
    }
    dialogbox.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    dialogbox.prototype.onConformClick = function () {
        this.dialogRef.close(this.conform);
    };
    dialogbox.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"],] }] }
    ]; };
    dialogbox = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dialogbox.component',
            template: __importDefault(__webpack_require__(/*! raw-loader!../dialogbox/dialogbox.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/dialogbox.component.html")).default,
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], dialogbox);
    return dialogbox;
}());

var detailBox = /** @class */ (function () {
    function detailBox(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.conform = "conform";
    }
    detailBox.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    detailBox.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"],] }] }
    ]; };
    detailBox = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'detailBox.component',
            template: __importDefault(__webpack_require__(/*! raw-loader!../dialogbox/detail.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/detail.component.html")).default,
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], detailBox);
    return detailBox;
}());



/***/ }),

/***/ "./src/app/pages/offers-list/offers-list.component.css":
/*!*************************************************************!*\
  !*** ./src/app/pages/offers-list/offers-list.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL29mZmVycy1saXN0L29mZmVycy1saXN0LmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/offers-list/offers-list.component.ts":
/*!************************************************************!*\
  !*** ./src/app/pages/offers-list/offers-list.component.ts ***!
  \************************************************************/
/*! exports provided: OffersListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OffersListComponent", function() { return OffersListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var OffersListComponent = /** @class */ (function () {
    function OffersListComponent(auth, router, Spinner) {
        this.auth = auth;
        this.router = router;
        this.Spinner = Spinner;
        this.OfferList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.getOfferList();
    }
    OffersListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 2
        };
        this.setinterval = setInterval(function () {
            _this.gettopbardataData();
        }, 800000);
    };
    OffersListComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
        this.dtTrigger.unsubscribe();
    };
    OffersListComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    OffersListComponent.prototype.getOfferList = function () {
        var _this = this;
        this.Spinner.show();
        this.auth.getOfferList(this.api_token).subscribe(function (x) {
            _this.Spinner.hide();
            if (x["status"] == "success") {
                _this.OfferList = x['data'];
                //this.dtTrigger.next();
            }
        });
    };
    OffersListComponent.prototype.Edit = function (id) {
        this.router.navigate(["/add_offers"], { queryParams: { Id: id } });
    };
    OffersListComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    OffersListComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    OffersListComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_5__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_5__["DataTableDirective"])
    ], OffersListComponent.prototype, "dtElement", void 0);
    OffersListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-offers-list',
            template: __importDefault(__webpack_require__(/*! raw-loader!./offers-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/offers-list/offers-list.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./offers-list.component.css */ "./src/app/pages/offers-list/offers-list.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"]])
    ], OffersListComponent);
    return OffersListComponent;
}());



/***/ }),

/***/ "./src/app/pages/pending-orders/pending-orders.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/pages/pending-orders/pending-orders.component.css ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3BlbmRpbmctb3JkZXJzL3BlbmRpbmctb3JkZXJzLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/pending-orders/pending-orders.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/pending-orders/pending-orders.component.ts ***!
  \******************************************************************/
/*! exports provided: PendingOrdersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PendingOrdersComponent", function() { return PendingOrdersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var PendingOrdersComponent = /** @class */ (function () {
    function PendingOrdersComponent(auth, router, dialog, Spinner) {
        this.auth = auth;
        this.router = router;
        this.dialog = dialog;
        this.Spinner = Spinner;
        this.newOrderList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.api_token = this.auth.getToken();
        this.getPendingOrderList();
    }
    PendingOrdersComponent.prototype.ngOnInit = function () {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        // this.setinterval=  setInterval(() => {
        //   this.getPendingOrderList(); 
        // }, 800000);
    };
    PendingOrdersComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    PendingOrdersComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    PendingOrdersComponent.prototype.ngOnDestroy = function () {
        // if( this.setinterval)
        // {
        //   clearInterval(this.setinterval);
        // }
        this.dtTrigger.unsubscribe();
    };
    PendingOrdersComponent.prototype.getPendingOrderList = function () {
        var _this = this;
        // this.Spinner.show();
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getPendingOrder(this.api_token).subscribe(function (res) {
                // this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                        _this.newOrderList = res["data"]["OrderList"];
                        //  this.dtTrigger.next();
                    }
                }
            });
        }
    };
    PendingOrdersComponent.prototype.detailClick = function (id) {
        var _this = this;
        this.auth.getOrderDetail(this.api_token, id).subscribe(function (res) {
            if (res["status"] == 'success') {
                var dialogRef = _this.dialog.open(_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["detailBox"], {
                    width: '500px',
                    data: res["data"]
                });
                dialogRef.afterClosed().subscribe(function (result) {
                });
            }
        });
    };
    PendingOrdersComponent.prototype.onConformClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["dialogbox"], {
            width: '500px',
            data: { type: "Conform Order", Message: "Are you sure you want to Accept this Order!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
            console.log(result);
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            status: "conformed",
                            id: id
                        };
                        _this.auth.saveOrderStatus(data).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getPendingOrderList();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    PendingOrdersComponent.prototype.onCancelClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_7__["dialogbox"], {
            width: '500px',
            data: { type: "Cancelled Order", Message: "Are you sure you want to Cancelled this Order!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
            console.log(result);
            if (result != undefined) {
                if (result == "conform") {
                    _this.Spinner.show();
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            status: "cancelled",
                            id: id
                        };
                        _this.auth.saveOrderStatus(data).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getPendingOrderList();
                            }
                        });
                    }
                    else {
                        _this.Spinner.hide();
                    }
                }
            }
        });
    };
    PendingOrdersComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"])
    ], PendingOrdersComponent.prototype, "dtElement", void 0);
    PendingOrdersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-pending-orders',
            template: __importDefault(__webpack_require__(/*! raw-loader!./pending-orders.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pending-orders/pending-orders.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./pending-orders.component.css */ "./src/app/pages/pending-orders/pending-orders.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"], ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"]])
    ], PendingOrdersComponent);
    return PendingOrdersComponent;
}());



/***/ }),

/***/ "./src/app/pages/pending-users/pending-users.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/pages/pending-users/pending-users.component.css ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3BlbmRpbmctdXNlcnMvcGVuZGluZy11c2Vycy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/pending-users/pending-users.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/pending-users/pending-users.component.ts ***!
  \****************************************************************/
/*! exports provided: PendingUsersComponent, dialogbox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PendingUsersComponent", function() { return PendingUsersComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dialogbox", function() { return dialogbox; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







var PendingUsersComponent = /** @class */ (function () {
    function PendingUsersComponent(auth, router, dialog, Spinner) {
        this.auth = auth;
        this.router = router;
        this.dialog = dialog;
        this.Spinner = Spinner;
        this.newUserList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.api_token = this.auth.getToken();
        this.getPandingUserData();
    }
    PendingUsersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        this.setinterval = setInterval(function () {
            _this.getPandingUserData();
        }, 800000);
    };
    PendingUsersComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
        this.dtTrigger.unsubscribe();
    };
    PendingUsersComponent.prototype.getPandingUserData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getPendingUserList(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                        _this.newUserList = res["data"]["newUserList"];
                        //this.dtTrigger.next();
                    }
                }
            });
        }
    };
    PendingUsersComponent.prototype.onActiveClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "active", Message: "Are you sure you want to active this user!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
            console.log(result);
            if (result != undefined) {
                if (result == "conform") {
                    if (_this.api_token != null && _this.api_token != undefined) {
                        _this.Spinner.show();
                        _this.auth.saveUserStatus(_this.api_token, 'active', id).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getPandingUserData();
                            }
                        });
                    }
                }
            }
        });
    };
    PendingUsersComponent.prototype.onRejectClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Decline", Message: "Are you sure you want to Decline this user!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
            console.log(result);
            if (result != undefined) {
                if (result == "conform") {
                    if (_this.api_token != null && _this.api_token != undefined) {
                        _this.Spinner.show();
                        _this.auth.saveUserStatus(_this.api_token, 'reject', id).subscribe(function (res) {
                            _this.Spinner.hide();
                            if (res["status"] == 'success') {
                                _this.getPandingUserData();
                            }
                        });
                    }
                }
            }
        });
    };
    PendingUsersComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    PendingUsersComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    PendingUsersComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_6__["DataTableDirective"])
    ], PendingUsersComponent.prototype, "dtElement", void 0);
    PendingUsersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-pending-users',
            template: __importDefault(__webpack_require__(/*! raw-loader!./pending-users.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pending-users/pending-users.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./pending-users.component.css */ "./src/app/pages/pending-users/pending-users.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"], ngx_spinner__WEBPACK_IMPORTED_MODULE_4__["NgxSpinnerService"]])
    ], PendingUsersComponent);
    return PendingUsersComponent;
}());

var dialogbox = /** @class */ (function () {
    function dialogbox(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.conform = "conform";
    }
    dialogbox.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    dialogbox.prototype.onConformClick = function () {
        this.dialogRef.close(this.conform);
    };
    dialogbox.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"],] }] }
    ]; };
    dialogbox = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dialogbox.component',
            template: __importDefault(__webpack_require__(/*! raw-loader!../dialogbox/dialogbox.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/dialogbox.component.html")).default,
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"], Object])
    ], dialogbox);
    return dialogbox;
}());



/***/ }),

/***/ "./src/app/pages/product-list/product-list.component.css":
/*!***************************************************************!*\
  !*** ./src/app/pages/product-list/product-list.component.css ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Byb2R1Y3QtbGlzdC9wcm9kdWN0LWxpc3QuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/product-list/product-list.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/product-list/product-list.component.ts ***!
  \**************************************************************/
/*! exports provided: ProductListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListComponent", function() { return ProductListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../message-box/message-box.component */ "./src/app/pages/message-box/message-box.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var ProductListComponent = /** @class */ (function () {
    function ProductListComponent(auth, router, Spinner, dialog) {
        this.auth = auth;
        this.router = router;
        this.Spinner = Spinner;
        this.dialog = dialog;
        this.productList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.getProductList();
    }
    ProductListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        this.setinterval = setInterval(function () {
            _this.gettopbardataData();
        }, 800000);
    };
    ProductListComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
        this.dtTrigger.unsubscribe();
    };
    ProductListComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    ProductListComponent.prototype.getProductList = function () {
        var _this = this;
        this.Spinner.show();
        this.auth.getProductList(this.api_token).subscribe(function (x) {
            _this.Spinner.hide();
            if (x["status"] == "success") {
                _this.productList = x['data'];
                // this.dtTrigger.next();
            }
        });
    };
    ProductListComponent.prototype.Edit = function (id) {
        this.router.navigate(["/add_product"], { queryParams: { Id: id } });
    };
    ProductListComponent.prototype.Delete = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(_message_box_message_box_component__WEBPACK_IMPORTED_MODULE_5__["MessageBoxComponent"], {
            width: '500px',
            data: { type: "Delete", Message: "Are you sure you want to Delete!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            type: "delete",
                            id: id
                        };
                        _this.auth.postproductDelete(data).subscribe(function (res) {
                            if (res["status"] == 'success') {
                                _this.getProductList();
                            }
                        });
                    }
                }
            }
        });
    };
    ProductListComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    ProductListComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    ProductListComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_7__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_7__["DataTableDirective"])
    ], ProductListComponent.prototype, "dtElement", void 0);
    ProductListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-product-list',
            template: __importDefault(__webpack_require__(/*! raw-loader!./product-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/product-list/product-list.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./product-list.component.css */ "./src/app/pages/product-list/product-list.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]])
    ], ProductListComponent);
    return ProductListComponent;
}());



/***/ }),

/***/ "./src/app/pages/sub-categories/sub-categories.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/pages/sub-categories/sub-categories.component.css ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N1Yi1jYXRlZ29yaWVzL3N1Yi1jYXRlZ29yaWVzLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/sub-categories/sub-categories.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/sub-categories/sub-categories.component.ts ***!
  \******************************************************************/
/*! exports provided: SubCategoriesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubCategoriesComponent", function() { return SubCategoriesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var _message_box_message_box_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../message-box/message-box.component */ "./src/app/pages/message-box/message-box.component.ts");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var SubCategoriesComponent = /** @class */ (function () {
    function SubCategoriesComponent(auth, router, Spinner, dialog) {
        this.auth = auth;
        this.router = router;
        this.Spinner = Spinner;
        this.dialog = dialog;
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.api_token = this.auth.getToken();
        this.gettopbardataData();
        this.GetCategoryList();
    }
    SubCategoriesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        this.setinterval = setInterval(function () {
            _this.gettopbardataData();
        }, 800000);
    };
    SubCategoriesComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
        this.dtTrigger.unsubscribe();
    };
    SubCategoriesComponent.prototype.gettopbardataData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getTopdata(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                    }
                }
            });
        }
    };
    SubCategoriesComponent.prototype.GetCategoryList = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getSubCategoryList(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                _this.categoryList = "";
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.categoryList = res["data"];
                        //this.dtTrigger.next();
                    }
                }
            });
        }
    };
    SubCategoriesComponent.prototype.Editcategory = function (id) {
        this.router.navigate(["/add_sub_category"], { queryParams: { Id: id } });
    };
    SubCategoriesComponent.prototype.Deletecategory = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(_message_box_message_box_component__WEBPACK_IMPORTED_MODULE_6__["MessageBoxComponent"], {
            width: '500px',
            data: { type: "Delete", Message: "Are you sure you want to Delete!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result != undefined) {
                if (result == "conform") {
                    if (_this.api_token != null && _this.api_token != undefined) {
                        var data = {
                            api_token: _this.api_token,
                            type: "delete",
                            id: id
                        };
                        _this.auth.postSubCategoryDelete(data).subscribe(function (res) {
                            if (res["status"] == 'success') {
                                _this.GetCategoryList();
                            }
                        });
                    }
                }
            }
        });
    };
    SubCategoriesComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    SubCategoriesComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    SubCategoriesComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_7__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_7__["DataTableDirective"])
    ], SubCategoriesComponent.prototype, "dtElement", void 0);
    SubCategoriesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-sub-categories',
            template: __importDefault(__webpack_require__(/*! raw-loader!./sub-categories.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sub-categories/sub-categories.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./sub-categories.component.css */ "./src/app/pages/sub-categories/sub-categories.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]])
    ], SubCategoriesComponent);
    return SubCategoriesComponent;
}());



/***/ }),

/***/ "./src/app/pages/user-profile/user-profile.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card-profile-image img {\n  -webkit-transform: translate(-50%, 30%);\n          transform: translate(-50%, 30%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdXNlci1wcm9maWxlL0M6XFxNWVBvamVjdHNcXEdpdEZvbGRlclxcYWRtaW5QYW5lbC9zcmNcXGFwcFxccGFnZXNcXHVzZXItcHJvZmlsZVxcdXNlci1wcm9maWxlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy91c2VyLXByb2ZpbGUvdXNlci1wcm9maWxlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksdUNBQUE7VUFBQSwrQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdXNlci1wcm9maWxlL3VzZXItcHJvZmlsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uY2FyZC1wcm9maWxlLWltYWdlIGltZyB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAzMCUpO1xyXG59IiwiLmNhcmQtcHJvZmlsZS1pbWFnZSBpbWcge1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAzMCUpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/user-profile/user-profile.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.component.ts ***!
  \**************************************************************/
/*! exports provided: UserProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfileComponent", function() { return UserProfileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/__ivy_ngcc__/fesm5/ngx-spinner.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var fd = new FormData();
var UserProfileComponent = /** @class */ (function () {
    function UserProfileComponent(auth, router, Spinner) {
        this.auth = auth;
        this.router = router;
        this.Spinner = Spinner;
        this.UserData = {
            api_token: "",
            UserName: "",
            email: "",
            company_name: "",
            about_us: "",
            address_id: 0,
            country: "Kuwait",
            address1: "",
            address2: "",
            city: "Kuwait",
            area: "",
            postal_code: "",
            phone_no: "",
            phone_no2: "",
            logo: "http://golden-handle.com/logo.png"
        };
        this.showEmailval = false;
        this.imageShow = false;
        this.fileToUpload = "";
        this.imagePath = "";
        this.api_token = this.auth.getToken();
        this.getAdminData();
    }
    UserProfileComponent.prototype.ngOnInit = function () {
    };
    UserProfileComponent.prototype.handleFileInput = function (files) { this.fileToUpload = files.item(0); };
    UserProfileComponent.prototype.getAdminData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.Spinner.show();
            this.auth.getAdminDetail(this.api_token).subscribe(function (res) {
                _this.Spinner.hide();
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.UserData = res["data"];
                        if (_this.UserData != null) {
                            console.log(_this.UserData);
                            if (_this.UserData.company_name == null || _this.UserData.company_name == undefined || _this.UserData.company_name == "") {
                                _this.UserData.company_name = "Jain Hardware and power tools";
                            }
                        }
                    }
                }
            });
        }
    };
    UserProfileComponent.prototype.validationCheck = function () {
        if (this.UserData.address1.trim() == "" ||
            this.UserData.about_us.trim() == "") {
            return false;
        }
        return true;
    };
    UserProfileComponent.prototype.onSaveClick = function () {
        var _this = this;
        if (this.validationCheck() == true) {
            this.Spinner.show();
            this.UserData.api_token = this.api_token;
            fd.append('image', this.fileToUpload);
            fd.append('api_token', this.api_token);
            fd.append('address1', this.UserData.address1);
            fd.append('about_us', this.UserData.about_us);
            fd.append('postal_code', this.UserData.postal_code);
            fd.append('phone_no', this.UserData.phone_no);
            fd.append('phone_no2', this.UserData.phone_no2);
            this.auth.saveAdminData(fd).subscribe(function (res) {
                if (res["status"] == 'success') {
                    _this.Spinner.hide();
                    _this.getAdminData();
                }
            });
        }
    };
    UserProfileComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"] }
    ]; };
    UserProfileComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user-profile',
            template: __importDefault(__webpack_require__(/*! raw-loader!./user-profile.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-profile/user-profile.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./user-profile.component.scss */ "./src/app/pages/user-profile/user-profile.component.scss")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_spinner__WEBPACK_IMPORTED_MODULE_3__["NgxSpinnerService"]])
    ], UserProfileComponent);
    return UserProfileComponent;
}());



/***/ }),

/***/ "./src/app/pages/users/users.component.css":
/*!*************************************************!*\
  !*** ./src/app/pages/users/users.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3VzZXJzL3VzZXJzLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/users/users.component.ts":
/*!************************************************!*\
  !*** ./src/app/pages/users/users.component.ts ***!
  \************************************************/
/*! exports provided: UsersComponent, dialogbox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersComponent", function() { return UsersComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dialogbox", function() { return dialogbox; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/provider/auth.service */ "./src/app/provider/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm5/dialog.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-datatables */ "./node_modules/angular-datatables/__ivy_ngcc__/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var UsersComponent = /** @class */ (function () {
    function UsersComponent(auth, router, dialog) {
        this.auth = auth;
        this.router = router;
        this.dialog = dialog;
        this.newUserList = [];
        this.dtOptions = {};
        this.dtTrigger = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.api_token = this.auth.getToken();
        this.getActiveUserData();
    }
    UsersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 20
        };
        this.setinterval = setInterval(function () {
            _this.getActiveUserData();
        }, 800000);
    };
    UsersComponent.prototype.ngOnDestroy = function () {
        if (this.setinterval) {
            clearInterval(this.setinterval);
        }
        this.dtTrigger.unsubscribe();
    };
    UsersComponent.prototype.getActiveUserData = function () {
        var _this = this;
        if (this.api_token != null && this.api_token != undefined) {
            this.auth.getActiveUserList(this.api_token).subscribe(function (res) {
                if (res["status"] == 'success') {
                    if (res["data"] != '') {
                        _this.dataArray = [];
                        _this.dataArray['pendingOrder'] = res["data"]["newCountOrder"];
                        _this.dataArray['newUserCount'] = res["data"]["newUserCount"];
                        _this.dataArray['RegisterUser'] = res["data"]["registerUserCount"];
                        _this.dataArray['promotion'] = res["data"]["promocode"];
                        _this.dataArray['conformorder'] = res["data"]["conformorder"];
                        _this.newUserList = res["data"]["newUserList"];
                        //this.dtTrigger.next();
                    }
                }
            });
        }
    };
    UsersComponent.prototype.onRejectClick = function (id) {
        var _this = this;
        var dialogRef = this.dialog.open(dialogbox, {
            width: '500px',
            data: { type: "Decline", Message: "Are you sure you want to Decline this user!" }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
            console.log(result);
            if (result != undefined) {
                if (result == "conform") {
                    if (_this.api_token != null && _this.api_token != undefined) {
                        _this.auth.saveUserStatus(_this.api_token, 'reject', id).subscribe(function (res) {
                            if (res["status"] == 'success') {
                                _this.getActiveUserData();
                            }
                        });
                    }
                }
            }
        });
    };
    UsersComponent.prototype.ngAfterViewInit = function () {
        this.dtTrigger.next();
    };
    UsersComponent.prototype.rerender = function () {
        var _this = this;
        this.dtElement.dtInstance.then(function (dtInstance) {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            _this.dtTrigger.next();
        });
    };
    UsersComponent.ctorParameters = function () { return [
        { type: src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(angular_datatables__WEBPACK_IMPORTED_MODULE_5__["DataTableDirective"], { static: false }),
        __metadata("design:type", angular_datatables__WEBPACK_IMPORTED_MODULE_5__["DataTableDirective"])
    ], UsersComponent.prototype, "dtElement", void 0);
    UsersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-users',
            template: __importDefault(__webpack_require__(/*! raw-loader!./users.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/users/users.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./users.component.css */ "./src/app/pages/users/users.component.css")).default]
        }),
        __metadata("design:paramtypes", [src_app_provider_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]])
    ], UsersComponent);
    return UsersComponent;
}());

var dialogbox = /** @class */ (function () {
    function dialogbox(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.conform = "conform";
    }
    dialogbox.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    dialogbox.prototype.onConformClick = function () {
        this.dialogRef.close(this.conform);
    };
    dialogbox.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"],] }] }
    ]; };
    dialogbox = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dialogbox.component',
            template: __importDefault(__webpack_require__(/*! raw-loader!../dialogbox/dialogbox.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dialogbox/dialogbox.component.html")).default,
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"], Object])
    ], dialogbox);
    return dialogbox;
}());



/***/ })

}]);
//# sourceMappingURL=layouts-admin-layout-admin-layout-module.js.map