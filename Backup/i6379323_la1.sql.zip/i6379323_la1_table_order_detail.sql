
-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `itemedition_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `order_id`, `itemedition_id`, `created_at`, `updated_at`, `quantity`, `price`) VALUES
(24, 23, 29, '2020-07-04 21:24:34', '2020-07-04 21:24:34', 2, 1000.00),
(23, 22, 29, '2020-07-04 10:50:31', '2020-07-04 10:50:31', 1, 1000.00),
(22, 21, 32, '2020-06-29 14:23:51', '2020-06-29 14:23:51', 15, 3.50),
(21, 20, 27, '2020-06-29 00:18:30', '2020-06-29 00:18:30', 1, 1200.00),
(20, 19, 32, '2020-06-28 19:39:11', '2020-06-28 19:39:11', 10, 3.50),
(19, 19, 31, '2020-06-28 19:39:11', '2020-06-28 19:39:11', 2, 10.00),
(18, 18, 26, '2020-06-27 13:04:13', '2020-06-27 13:04:13', 5, 10.00),
(17, 17, 26, '2020-06-27 11:51:53', '2020-06-27 11:51:53', 5, 10.00),
(16, 16, 26, '2020-06-02 12:50:32', '2020-06-02 12:50:32', 1, 10.00);
