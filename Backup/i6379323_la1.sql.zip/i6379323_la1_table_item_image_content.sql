
-- --------------------------------------------------------

--
-- Table structure for table `item_image_content`
--

CREATE TABLE `item_image_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemDetail_id` int(10) UNSIGNED NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageURL` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_image_content`
--

INSERT INTO `item_image_content` (`id`, `itemDetail_id`, `description`, `imageURL`, `size`, `type`, `created_at`, `updated_at`) VALUES
(28, 26, NULL, '26/Drill_Machine_1590655476.jpg', NULL, 'Other', '2020-05-28 15:45:45', '2020-05-28 15:45:45'),
(27, 26, NULL, '26/Drill_Machine_1590655473.png', NULL, 'Other', '2020-05-28 15:45:45', '2020-05-28 15:45:45'),
(26, 26, NULL, '26/Drill_Machine_1590655469.png', NULL, 'Other', '2020-05-28 15:45:45', '2020-05-28 15:45:45'),
(25, 26, NULL, '26/Drill_Machine_1590655459.jpeg', NULL, 'Main', '2020-05-28 15:45:45', '2020-05-28 15:45:45'),
(24, 25, NULL, '25/Robin_Generator_1590654358.jpeg', NULL, 'Other', '2020-05-28 15:26:48', '2020-05-28 15:26:48'),
(23, 25, NULL, '25/Robin_Generator_1590654354.jpeg', NULL, 'Other', '2020-05-28 15:26:48', '2020-05-28 15:26:48'),
(22, 25, NULL, '25/Robin_Generator_1590654347.png', NULL, 'Main', '2020-05-28 15:26:48', '2020-05-28 15:26:48'),
(21, 24, NULL, '24/Sub_category_e_1590653623.png', NULL, 'Main', '2020-05-28 15:13:57', '2020-05-28 15:13:57'),
(20, 23, NULL, '23/Sub_category_w_1590653459.png', NULL, 'Main', '2020-05-28 15:11:14', '2020-05-28 15:11:14'),
(19, 22, NULL, '22/detailsetting_1590653239.png', NULL, 'Other', '2020-05-28 15:07:52', '2020-05-28 15:07:52'),
(18, 22, NULL, '22/detailsetting_1590653228.jpg', NULL, 'Main', '2020-05-28 15:07:51', '2020-05-28 15:07:51'),
(29, 27, NULL, '27/Reconnect_1.5_Ton_3_Star_XS-183BX0_Inverter_Split_AC_1590807117.jpg', NULL, 'Main', '2020-05-30 09:53:06', '2020-05-30 09:53:06'),
(30, 27, NULL, '27/Reconnect_1.5_Ton_3_Star_XS-183BX0_Inverter_Split_AC_1590807128.jpg', NULL, 'Other', '2020-05-30 09:53:06', '2020-05-30 09:53:06'),
(31, 28, NULL, '28/Reconnect_1.5_Ton_3_Star_XS-183BX0_Inverter_Split_AC_1590807546.jpg', NULL, 'Main', '2020-05-30 10:00:00', '2020-05-30 10:00:00'),
(32, 28, NULL, '28/Reconnect_1.5_Ton_3_Star_XS-183BX0_Inverter_Split_AC_1590807554.jpg', NULL, 'Other', '2020-05-30 10:00:00', '2020-05-30 10:00:00'),
(33, 29, NULL, '29/Daikin_1.5_Ton_3_Star_ATKL_Series_ATKL50TV16U_Inverter_Split_AC_1590807712.jpg', NULL, 'Main', '2020-05-30 10:02:50', '2020-05-30 10:02:50'),
(34, 29, NULL, '29/Daikin_1.5_Ton_3_Star_ATKL_Series_ATKL50TV16U_Inverter_Split_AC_1590807719.jpg', NULL, 'Other', '2020-05-30 10:02:50', '2020-05-30 10:02:50'),
(35, 30, NULL, '30/Nova_Safe_Yellow_Hard_Safety_Helmet,_1590808249.jpg', NULL, 'Main', '2020-05-30 10:11:25', '2020-05-30 10:11:25'),
(36, 31, NULL, '31/MAX-BOLD_1591022426.jpg', NULL, 'Main', '2020-06-01 21:42:16', '2020-06-01 21:42:16');
