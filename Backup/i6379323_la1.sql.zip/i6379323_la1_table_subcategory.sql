
-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `category_name`, `photo`, `category_id`, `created_at`, `updated_at`, `is_deleted`) VALUES
(4, 'Makita', '1590640020.jpg', 4, '2020-05-28 11:27:00', '2020-05-28 11:27:00', 0),
(3, 'Bosch', '1590640003.jpg', 4, '2020-05-28 11:26:43', '2020-05-28 11:26:43', 0),
(5, 'DiWalt', '1590640037.jpg', 4, '2020-05-28 11:27:17', '2020-05-28 11:27:17', 0),
(6, 'DCA', '1590640050.jpg', 4, '2020-05-28 11:27:30', '2020-05-28 11:27:30', 0);
