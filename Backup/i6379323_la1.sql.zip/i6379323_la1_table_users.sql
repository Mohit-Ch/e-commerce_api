
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_token` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_Name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT '0',
  `usertype` enum('Admin','User') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'User',
  `photoUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `api_token`, `remember_token`, `created_at`, `updated_at`, `photo`, `user_Name`, `is_active`, `usertype`, `photoUrl`, `company_name`, `phone_no`) VALUES
(3, 'admin', 'admin@golden-handle.com', '$2y$10$f/5D/ruppE93LHqcmQ0Loenc.GdrkcAT6gb3/BYnGuQogTp08VYbG', 'pV6KGKDrEZyBhFcNNBbV6cREMaRayJxgZxkbXysgzmUgwY0zI4vE0UWAJ9nC', NULL, '2020-04-14 14:07:07', '2020-12-19 16:45:56', NULL, 'admin@golden-handle.com', 0, 'Admin', NULL, NULL, NULL),
(4, 'Developer Account', 'developer@golden-handle.com', '$2y$10$3bJT8JjblzTpbOFRU7KR6Ov9EXGX4W4kLpnz3rBOHqX6cb7qgHany', 'aGsbTZPVgStJRlz5E11q6EsjUX2Lw7iVp8U4Vb6l6WsT1NQ2SUX650M7YaXL', NULL, '2020-04-14 14:07:35', '2020-12-19 15:43:31', NULL, 'developer@golden-handle.com', 0, 'Admin', NULL, NULL, NULL),
(6, 'manresh yadav', 'manreshyadav@gmail.com', '$2y$10$RmcTX5uaarUGSUzhdKwW/uB5y9p7IMqDIbjc8YNvkOVufo9UCHYu6', 'H6Jb0L89WxRrmx6dqWbivOle0IluUWHoDDTmQUT9CIISqxzxGSey04Fxj9BX', NULL, '2020-06-27 11:51:53', '2020-07-04 08:42:50', NULL, 'manreshyadav@gmail.com', 0, 'User', NULL, NULL, '08882262496'),
(7, 'manresh yadav', 'manreshyadav1@gmail.com', '$2y$10$kbB2oep4oEGOe8P47N4eoOvVuC1C.NO.jOco1RKITszpywqlUVfb6', 'taRZgCsRNLDTiYZ73k0Q1XDQbXIJcfAk1HGyf1jgILErgsi1c2U6O4M7NYJ2', NULL, '2020-06-29 00:18:30', '2020-07-04 20:51:08', NULL, 'manreshyadav1@gmail.com', 1, 'User', NULL, NULL, '08882262496'),
(8, 'mohit choudhary', 'mohit03.10.92@gmail.com', '$2y$10$buKXicgH/2SNk4S1H2F0Mu1kq6FgueapoxAc/R1CbCigSWFv9Ri.C', '90MnigZnYTgVaB6q4XMXi0B82qujCEagbYBWLO4bbvcSvXAv5HLf5mt9AzF5', NULL, '2020-06-29 14:23:51', '2020-07-07 21:10:29', NULL, 'mohit03.10.92@gmail.com', 1, 'User', NULL, NULL, '8800609984');
