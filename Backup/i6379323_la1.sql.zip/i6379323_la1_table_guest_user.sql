
-- --------------------------------------------------------

--
-- Table structure for table `guest_user`
--

CREATE TABLE `guest_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `guest_user`
--

INSERT INTO `guest_user` (`id`, `name`, `company_name`, `email`, `phone_no`, `address`, `created_at`, `updated_at`) VALUES
(17, 'mohit choudhary', 'mohit choudhary', 'mohit03.10.92@gmail.com', '8800609984', 'Kuwait, Kuwait, Kuwait, 123456', '2020-06-28 19:39:11', '2020-06-28 19:39:11'),
(16, 'mohit choudhary', 'mohit choudhary', 'mohit03.10.92@gmail.com', '8800609984', 'Gurgaon, Kuwait, Kuwait, 123456', '2020-06-02 12:50:29', '2020-06-02 12:50:29');
