
-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_02_22_141629_add_api_token_to_users', 1),
(4, '2020_02_22_155345_alter__users', 1),
(5, '2020_02_22_164933_create__error_log_table', 1),
(6, '2020_02_22_165327_create__address_table', 1),
(7, '2020_02_22_171219_create_category_table', 1),
(8, '2020_02_22_171241_create_subcategory_table', 1),
(9, '2020_02_22_172008_create_item_deatil_table', 1),
(10, '2020_02_23_031226_create_item_edition_table', 1),
(11, '2020_02_23_034244_create_item_details_attributes_table', 1),
(12, '2020_02_23_034455_create_item_image_content_table', 1),
(13, '2020_02_23_035735_create_promocode_table', 1),
(14, '2020_02_29_083346_create_order_table', 1),
(15, '2020_02_29_085436_create_order_detail_table', 1),
(16, '2020_02_29_085738_create_guest_user_table', 1),
(17, '2020_03_29_050733_alteruserstable', 1),
(18, '2020_03_29_051906_alterpromocodetable', 1),
(19, '2020_04_05_094226_alter__orderdetail_table', 1),
(20, '2020_04_10_150816_altercategorytable', 1),
(21, '2020_04_10_161453_altersubcategorytable', 1),
(22, '2020_04_11_112958_alteritem_details_attributestable', 1),
(23, '2020_04_12_000039_alteritem_deatiltable', 1),
(24, '2020_04_12_000220_alteritem_editiontable', 1),
(25, '2020_04_12_104712_alteritem_image_contenttable', 1),
(26, '2020_04_12_165529_alteritem_detailtable', 1),
(33, '2020_05_20_161742_alter_users_table', 2),
(37, '2020_05_20_161920_alter_usersadd_table', 4),
(41, '2020_05_17_070227_alteritem_editiontable', 6),
(36, '2020_05_17_070447_alterordertable', 3),
(38, '2020_05_20_162226_alter_orders_table', 5),
(39, '2020_05_20_162409_alter_ordercode_table', 5),
(40, '2020_05_20_232113_alter_orderadd_column_table', 5),
(42, '2020_05_23_115512_alter_addressdetail_table', 7),
(43, '2020_06_28_110824_alter_usersremove__table', 8),
(44, '2020_06_28_110913_alter__company_detail_table', 8);
