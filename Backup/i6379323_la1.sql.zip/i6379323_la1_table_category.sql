
-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `photo`, `created_at`, `updated_at`, `is_deleted`) VALUES
(6, 'Electronic Tools', '1590639771.jpg', '2020-05-28 11:22:51', '2020-05-28 11:22:51', 0),
(5, 'Generator', '1590639749.jpg', '2020-05-28 11:22:30', '2020-05-28 11:22:30', 0),
(4, 'Power Tools', '1590639724.jpg', '2020-05-28 11:22:05', '2020-05-28 11:22:05', 0),
(7, 'Tools', '1590639789.jpg', '2020-05-28 11:23:09', '2020-05-28 11:23:09', 0),
(8, 'Air Compressor', '1590639804.jpg', '2020-05-28 11:23:24', '2020-05-28 11:23:24', 0),
(9, 'Safety Kit', '1590639822.jpg', '2020-05-28 11:23:42', '2020-05-28 11:23:42', 0),
(10, 'Motor Rewinding Repair', '1590639873.jpg', '2020-05-28 11:24:33', '2020-05-28 11:24:33', 0),
(11, 'IRT 206', '1591022162.jpg', '2020-06-01 21:36:04', '2020-06-01 21:36:04', 0);
