
-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Kuwait ',
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `users_id`, `country`, `address1`, `address2`, `city`, `area`, `postal_code`, `is_default`, `created_at`, `updated_at`, `name`, `email`, `phone_no`, `company_name`) VALUES
(1, 5, 'Kuwait', 'House no', NULL, 'Kuwait', NULL, '12345', 0, '2020-05-21 22:49:28', '2020-05-21 22:49:28', NULL, NULL, NULL, NULL),
(3, 6, 'Kuwait', '93 radha puri Ext 2', NULL, 'Kuwait', NULL, '110051', 0, '2020-06-27 11:51:53', '2020-06-27 11:51:53', 'manresh yadav', 'manreshyadav@gmail.com', '08882262496', NULL),
(4, 6, 'Kuwait', '93 Radhapuri ext-2', NULL, 'Kuwait', NULL, '110051', 0, '2020-06-27 13:04:13', '2020-06-27 13:04:13', 'Manresh', 'Manreshyadav@gmail.com', '8882262496', NULL),
(5, 7, 'Kuwait', '93 radha puri Ext 2', NULL, 'Kuwait', NULL, '12456', 0, '2020-06-29 00:18:30', '2020-06-29 00:18:30', 'manresh yadav', 'manreshyadav1@gmail.com', '08882262496', NULL),
(6, 8, 'Kuwait', 'Gurgaon', NULL, 'Kuwait', NULL, '123456', 0, '2020-06-29 14:23:51', '2020-06-29 14:23:51', 'mohit choudhary', 'mohit03.10.92@gmail.com', '8800609984', 'mohit choudhary'),
(7, 7, 'Kuwait', '93 radha puri Ext 2', NULL, 'Kuwait', NULL, '123456', 0, '2020-07-04 10:50:31', '2020-07-04 10:50:31', 'manresh yadav', 'manreshyadav@gmail.com', '08882262496', NULL),
(8, 7, 'Kuwait', 'A 12 JAGAT PURI STREET NO. 5', NULL, 'Kuwait', NULL, '110051', 0, '2020-07-04 21:24:34', '2020-07-04 21:24:34', 'NITIN KUMAR', 'nitinyadav034@gmail.com', '07289821224', NULL);
