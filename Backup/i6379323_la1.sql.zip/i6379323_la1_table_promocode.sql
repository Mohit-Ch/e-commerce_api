
-- --------------------------------------------------------

--
-- Table structure for table `promocode`
--

CREATE TABLE `promocode` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('percentage','fixed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `minOrderAmount` int(11) NOT NULL,
  `maxDiscountAmount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `promocode`
--

INSERT INTO `promocode` (`id`, `user_id`, `code`, `description`, `type`, `amount`, `minOrderAmount`, `maxDiscountAmount`, `created_at`, `updated_at`, `start_date`, `end_date`) VALUES
(1, 3, 'Croxyn', '10% discount', 'percentage', 10.00, 10, 100, '2020-07-04 21:02:40', '2020-07-04 21:02:40', '2020-07-03 18:30:00', '2020-07-04 18:30:00');
