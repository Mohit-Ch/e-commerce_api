
-- --------------------------------------------------------

--
-- Table structure for table `item_edition`
--

CREATE TABLE `item_edition` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemDetail_id` int(10) UNSIGNED NOT NULL,
  `itemEditionName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  `reserveq` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_edition`
--

INSERT INTO `item_edition` (`id`, `itemDetail_id`, `itemEditionName`, `price`, `quantity`, `remark`, `status`, `created_at`, `updated_at`, `is_deleted`, `reserveq`) VALUES
(32, 31, 'MAX-BOLD', 3.50, 74, NULL, NULL, '2020-06-01 21:42:16', '2020-06-29 14:23:51', 0, 0),
(31, 30, 'Nova Safe Yellow Hard Safety Helmet,', 10.00, 0, NULL, NULL, '2020-05-30 10:11:25', '2020-06-28 19:39:11', 0, 0),
(30, 29, 'Daikin 1.5 Ton 3 Star ATKL Series ATKL50TV16U Inverter Split AC', 2000.00, 1000, NULL, NULL, '2020-05-30 10:02:50', '2020-05-30 10:02:50', 0, 0),
(29, 28, 'Reconnect 1.5 Ton 3 Star XS-183BX0 Inverter Split AC', 1000.00, 6, NULL, NULL, '2020-05-30 10:00:00', '2020-07-04 21:24:34', 0, 0),
(28, 27, 'Reconnect 1.5 Ton 3 Star XS-183BX0 Inverter Split AC', 1000.00, 0, NULL, NULL, '2020-05-30 09:53:06', '2020-06-21 20:46:26', 0, 0),
(27, 26, 'Drill Machine', 1200.00, 1489, NULL, NULL, '2020-05-28 15:45:45', '2020-06-29 00:18:30', 0, 0),
(26, 25, 'Robin Generator', 10.00, 20, NULL, NULL, '2020-05-28 15:26:48', '2020-06-27 13:04:13', 0, 0),
(25, 24, 'Sub category e', 1.25, 56, NULL, NULL, '2020-05-28 15:13:57', '2020-05-28 15:13:57', 0, 0),
(24, 23, 'Sub category w', 2.00, 20, 'zxcvcv xcfvxcv', NULL, '2020-05-28 15:11:14', '2020-05-28 15:12:56', 0, 0),
(23, 22, 'detailsetting', 1.00, 2, NULL, NULL, '2020-05-28 15:07:51', '2020-05-28 15:07:51', 0, 0);
