
-- --------------------------------------------------------

--
-- Table structure for table `item_details_attributes`
--

CREATE TABLE `item_details_attributes` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemDetail_id` int(10) UNSIGNED NOT NULL,
  `AttributeKey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `AttributeValue` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_details_attributes`
--

INSERT INTO `item_details_attributes` (`id`, `itemDetail_id`, `AttributeKey`, `type`, `created_at`, `updated_at`, `AttributeValue`) VALUES
(9, 30, 'Colour', NULL, '2020-05-30 10:11:25', '2020-05-30 10:11:25', 'Yellow'),
(8, 22, 'Sub category', NULL, '2020-05-28 15:07:52', '2020-05-28 15:07:52', 'Sub category');
