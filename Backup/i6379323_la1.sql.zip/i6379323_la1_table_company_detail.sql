
-- --------------------------------------------------------

--
-- Table structure for table `company_detail`
--

CREATE TABLE `company_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `Key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_detail`
--

INSERT INTO `company_detail` (`id`, `Key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'phone1', '0-0965-24828702', NULL, NULL),
(2, 'phone2', '0-0965-99261620', NULL, NULL),
(3, 'aboutus', 'Explore the range of evaluation boards that showcase our innovative and cost-effective solutions for all of today\'s major and small equipments.', NULL, NULL),
(4, 'address1', 'Capital, Area:- Shuwaikh Ind\'I (2), Blk : 001, Bldg: 59A000, St : 16th ST. Owner: Khalifa Khalaf Alxlullah AlEnezi,', NULL, NULL),
(5, 'postalcode', '00009', NULL, NULL),
(6, 'logo', 'logo.png', NULL, NULL);
