
-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('user','gest') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('placed','conformed','cancelled','delivered') COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `Discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `actual_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `address_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `promocode_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deviceId` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `order_no`, `user_id`, `description`, `type`, `status`, `product_amount`, `Discount`, `actual_amount`, `address_id`, `created_at`, `updated_at`, `promocode_id`, `name`, `email`, `phone_no`, `company_name`, `address`, `deviceId`) VALUES
(22, 'GHoiwh3z1xXz', 7, NULL, 'user', 'placed', 1000.00, 0.00, 1000.00, 7, '2020-07-04 10:50:31', '2020-07-04 10:50:31', 0, 'manresh yadav', 'manreshyadav@gmail.com', '08882262496', NULL, '93 radha puri Ext 2, Kuwait, Kuwait, 123456', '123456'),
(21, 'GHisNlIFKs3l', 8, 'This is a test order.please ignor this', 'user', 'placed', 52.50, 0.00, 52.50, 6, '2020-06-29 14:23:51', '2020-06-29 14:23:51', 0, 'mohit choudhary', 'mohit03.10.92@gmail.com', '8800609984', 'mohit choudhary', 'Gurgaon, Kuwait, Kuwait, 123456', '00000000-0000-0000-f786-b547de7926d3'),
(20, 'GHMQcZbTwC7P', 7, NULL, 'user', 'placed', 1200.00, 0.00, 1200.00, 5, '2020-06-29 00:18:30', '2020-06-29 00:18:30', 0, 'manresh yadav', 'manreshyadav1@gmail.com', '08882262496', NULL, '93 radha puri Ext 2, Kuwait, Kuwait, 12456', '123456'),
(19, 'GHjHRvRAhxFf', 17, NULL, 'gest', 'placed', 55.00, 0.00, 55.00, 0, '2020-06-28 19:39:11', '2020-06-28 19:39:11', 0, 'mohit choudhary', 'mohit03.10.92@gmail.com', '8800609984', 'mohit choudhary', 'Kuwait, Kuwait, Kuwait, 123456', '00000000-0000-0000-f786-b547de7926d3'),
(18, 'GHY807ebWLlX', 6, NULL, 'user', 'placed', 50.00, 0.00, 50.00, 4, '2020-06-27 13:04:13', '2020-06-27 13:04:13', 0, 'Manresh', 'Manreshyadav@gmail.com', '8882262496', NULL, '93 Radhapuri ext-2, Kuwait, Kuwait, 110051', '00000000-0000-0000-6a99-fe85ba8f99d8'),
(17, 'GHerfMmId7PM', 6, NULL, 'user', 'placed', 50.00, 0.00, 50.00, 3, '2020-06-27 11:51:53', '2020-06-27 11:51:53', 0, 'manresh yadav', 'manreshyadav@gmail.com', '08882262496', NULL, '93 radha puri Ext 2, Kuwait, Kuwait, 110051', '123456'),
(16, 'GH0I0aQqVv1M', 16, NULL, 'gest', 'placed', 20.00, 0.00, 20.00, 0, '2020-06-02 12:50:32', '2020-06-02 12:50:32', 0, 'mohit choudhary', 'mohit03.10.92@gmail.com', '8800609984', 'mohit choudhary', 'Gurgaon, Kuwait, Kuwait, 123456', '00000000-0000-0000-f786-b547de7926d3'),
(23, 'GHvtsLtdcJks', 7, 'data testing', 'user', 'placed', 2000.00, 0.00, 2000.00, 8, '2020-07-04 21:24:34', '2020-07-04 21:24:34', 0, 'NITIN KUMAR', 'nitinyadav034@gmail.com', '07289821224', NULL, 'A 12 JAGAT PURI STREET NO. 5, Kuwait, Kuwait, 110051', '123456');
